import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertDepositSchema, insertWithdrawalSchema, insertGameTransactionSchema, insertReferralSchema, insertReferralCommissionSchema } from "@shared/schema";
import { z } from "zod";
import Decimal from "decimal.js";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup OAuth authentication
  await setupAuth(app);

  // Auth user endpoint
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Email/Password Registration
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, email, password } = req.body;
      
      if (!username || !email || !password) {
        res.status(400).json({ error: "Username, email and password required" });
        return;
      }

      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        res.status(400).json({ error: "Username already taken" });
        return;
      }

      const bcrypt = require('bcryptjs');
      const hashedPassword = await bcrypt.hash(password, 10);
      
      const user = await storage.createUser({
        username: username,
        email: email,
        password: hashedPassword,
      });

      // Create session
      (req.session as any).userId = user.id;
      req.session.save(() => {
        res.json({ 
          success: true, 
          user: { id: user.id, email: user.email, balance: user.balance },
          message: "Аккаунт создан! Добро пожаловать в SHOTO!" 
        });
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ error: "Registration failed" });
    }
  });

  // Email/Password Login
  app.post("/api/auth/email-login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        res.status(400).json({ error: "Email and password required" });
        return;
      }

      const user = await storage.getUserByUsername(email);
      if (!user) {
        res.status(401).json({ error: "Invalid email or password" });
        return;
      }

      const bcrypt = require('bcryptjs');
      const validPassword = await bcrypt.compare(password, user.password);
      
      if (!validPassword) {
        res.status(401).json({ error: "Invalid email or password" });
        return;
      }

      // Create session
      (req.session as any).userId = user.id;
      req.session.save(() => {
        res.json({ 
          success: true, 
          user: { id: user.id, email: user.email, balance: user.balance },
          message: "Вход выполнен успешно!" 
        });
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(400).json({ error: "Login failed" });
    }
  });

  // Deposit endpoints
  app.post("/api/deposits", async (req, res) => {
    try {
      const body = insertDepositSchema.parse(req.body);
      const deposit = await storage.createDeposit(body);
      res.json(deposit);
    } catch (error) {
      res.status(400).json({ error: "Invalid deposit data" });
    }
  });

  app.get("/api/deposits/:userId", async (req, res) => {
    try {
      const deposits = await storage.getUserDeposits(req.params.userId);
      res.json(deposits);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch deposits" });
    }
  });

  app.patch("/api/deposits/:id/complete", async (req, res) => {
    try {
      const deposit = await storage.getDeposit(req.params.id);
      if (!deposit) {
        res.status(404).json({ error: "Deposit not found" });
        return;
      }

      // Update deposit status
      const updated = await storage.updateDepositStatus(req.params.id, "completed");
      
      // Add amount to user balance
      const user = await storage.getUser(deposit.userId);
      if (user) {
        const newBalance = new Decimal(user.balance).plus(deposit.amount).toString();
        await storage.updateUserBalance(deposit.userId, newBalance);

        // Handle referral commission (10%)
        try {
          // Check if this user was referred by someone
          const referrals = await storage.getReferrals().then((refs: any) => 
            refs.find((r: any) => r.referredId === deposit.userId)
          );
          
          if (referrals && referrals.referrerId) {
            const commission = new Decimal(deposit.amount).times(0.1).toString();
            
            // Create referral commission record
            await storage.createReferralCommission({
              referralId: referrals.id,
              referrerId: referrals.referrerId,
              depositId: deposit.id,
              commissionAmount: commission,
              depositAmount: deposit.amount,
              status: "completed",
            });

            // Add commission to referrer's balance
            const referrer = await storage.getUser(referrals.referrerId);
            if (referrer) {
              const newReferrerBalance = new Decimal(referrer.balance).plus(commission).toString();
              await storage.updateUserBalance(referrals.referrerId, newReferrerBalance);
            }

            // Update total commission
            await storage.updateReferralCommission(referrals.id, new Decimal(referrals.totalCommission).plus(commission).toString());
          }
        } catch (err) {
          console.log("Referral commission processing skipped", err);
        }
      }

      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to complete deposit" });
    }
  });

  // Withdrawal endpoints
  app.post("/api/withdrawals", async (req, res) => {
    try {
      const body = insertWithdrawalSchema.parse(req.body);
      
      // Get user to check balance
      const user = await storage.getUser(body.userId);
      if (!user) {
        res.status(404).json({ error: "User not found" });
        return;
      }

      const totalAmount = new Decimal(body.amount).plus(body.fee || 0);
      if (new Decimal(user.balance).lessThan(totalAmount)) {
        res.status(400).json({ error: "Insufficient balance" });
        return;
      }

      // Deduct from balance
      const newBalance = new Decimal(user.balance).minus(totalAmount).toString();
      await storage.updateUserBalance(body.userId, newBalance);

      const withdrawal = await storage.createWithdrawal(body);
      res.json(withdrawal);
    } catch (error) {
      res.status(400).json({ error: "Invalid withdrawal data" });
    }
  });

  app.get("/api/withdrawals/:userId", async (req, res) => {
    try {
      const withdrawals = await storage.getUserWithdrawals(req.params.userId);
      res.json(withdrawals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch withdrawals" });
    }
  });

  // Game transaction endpoints
  app.post("/api/game-transactions", async (req, res) => {
    try {
      const body = insertGameTransactionSchema.parse(req.body);
      
      // Get user or create if doesn't exist
      let user = await storage.getUser(body.userId);
      if (!user) {
        // Create user with hashed password
        const hashedPassword = await require('bcryptjs').hash('guest', 10);
        user = await storage.createUser({
          username: body.userId,
          password: hashedPassword,
          email: `${body.userId}@guest.local`,
        });
        // Set the ID returned from database
        user.id = body.userId;
      }

      const transaction = await storage.createGameTransaction(body);
      
      // Update balance if it's a win
      if (body.status === "win" && body.winAmount) {
        const newBalance = new Decimal(user.balance).plus(body.winAmount).toString();
        await storage.updateUserBalance(body.userId, newBalance);
      }
      // Deduct bet amount if loss
      else if (body.status === "loss") {
        const newBalance = new Decimal(user.balance).minus(body.betAmount).toString();
        if (new Decimal(newBalance).isNegative()) {
          res.status(400).json({ error: "Insufficient balance" });
          return;
        }
        await storage.updateUserBalance(body.userId, newBalance);
      }

      res.json(transaction);
    } catch (error) {
      console.error('Game transaction error:', error);
      res.status(400).json({ error: "Invalid game transaction data" });
    }
  });

  app.get("/api/game-transactions/:userId", async (req, res) => {
    try {
      const transactions = await storage.getUserGameTransactions(req.params.userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  // User balance endpoint
  app.get("/api/users/:userId", async (req, res) => {
    try {
      let user = await storage.getUser(req.params.userId);
      if (!user) {
        // Create user if doesn't exist
        const hashedPassword = await require('bcryptjs').hash('guest', 10);
        user = await storage.createUser({
          username: req.params.userId,
          password: hashedPassword,
          email: `${req.params.userId}@guest.local`,
        });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Add balance endpoint - for immediate deposits
  app.post("/api/balance/add", async (req, res) => {
    try {
      const { userId, amount } = req.body;
      
      if (!userId || !amount || isNaN(amount) || amount <= 0) {
        res.status(400).json({ error: "Invalid userId or amount" });
        return;
      }

      let user = await storage.getUser(userId);
      
      // Create user if doesn't exist
      if (!user) {
        const hashedPassword = await require('bcryptjs').hash('guest', 10);
        user = await storage.createUser({
          username: userId,
          password: hashedPassword,
          email: `${userId}@guest.local`,
        });
      }

      // Add amount to balance
      const newBalance = new Decimal(user.balance).plus(amount).toString();
      const updatedUser = await storage.updateUserBalance(userId, newBalance);

      res.json(updatedUser);
    } catch (error) {
      console.error("Add balance error:", error);
      res.status(500).json({ error: "Failed to add balance" });
    }
  });

  // Tinkoff webhook endpoint (placeholder for real integration)
  app.post("/api/tinkoff/webhook", async (req, res) => {
    try {
      // In production, verify signature from Tinkoff
      const { orderId, amount, status } = req.body;
      
      // Update deposit status
      if (orderId) {
        await storage.updateDepositStatus(orderId, status === "success" ? "completed" : "failed");
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  // Referral endpoints
  app.post("/api/referrals/create", async (req, res) => {
    try {
      const { referrerId } = req.body;
      
      // Check if referral already exists
      let referral = await storage.getReferralByReferrerId(referrerId);
      if (referral) {
        res.json(referral);
        return;
      }

      // Generate promo code
      const promoCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      const baseUrl = process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS}` : 'http://localhost:5000';
      const referralLink = `${baseUrl}?ref=${promoCode}`;

      const newReferral = await storage.createReferral({
        referrerId,
        referredId: undefined,
        promoCode,
        referralLink,
        totalCommission: "0",
        referralCount: 0,
      });

      res.json(newReferral);
    } catch (error) {
      res.status(400).json({ error: "Failed to create referral" });
    }
  });

  app.get("/api/referrals/:referrerId", async (req, res) => {
    try {
      const referral = await storage.getReferralByReferrerId(req.params.referrerId);
      if (!referral) {
        res.status(404).json({ error: "Referral not found" });
        return;
      }
      res.json(referral);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch referral" });
    }
  });

  app.get("/api/referrals/:referrerId/commissions", async (req, res) => {
    try {
      const referral = await storage.getReferralByReferrerId(req.params.referrerId);
      if (!referral) {
        res.status(404).json({ error: "Referral not found" });
        return;
      }

      const commissions = await storage.getReferralCommissions(referral.id);
      res.json(commissions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch commissions" });
    }
  });

  app.post("/api/referrals/use-code", async (req, res) => {
    try {
      const { promoCode, newUserId } = req.body;
      
      const referral = await storage.getReferralByCode(promoCode);
      if (!referral) {
        res.status(404).json({ error: "Invalid promo code" });
        return;
      }

      // Update referral with the new user who used the code
      await storage.updateReferredUser(promoCode, newUserId);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: "Failed to use promo code" });
    }
  });

  app.get("/api/referrals/:referrerId/invited", async (req, res) => {
    try {
      const invited = await storage.getReferredUsers(req.params.referrerId);
      res.json(invited);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch invited users" });
    }
  });

  app.post("/api/referrals/apply-code", async (req, res) => {
    try {
      const { promoCode, userId } = req.body;
      
      if (!promoCode || !userId) {
        res.status(400).json({ error: "Промокод и ID пользователя обязательны" });
        return;
      }

      // Check if referral with this code exists
      const referral = await storage.getReferralByCode(promoCode);
      if (!referral) {
        res.status(404).json({ error: "Промокод не найден" });
        return;
      }

      // Check if user already used a referral code
      const existingReferrals = await storage.getReferrals();
      const userAlreadyReferred = existingReferrals.some((r: any) => r.referredId === userId);
      if (userAlreadyReferred) {
        res.status(400).json({ error: "Вы уже использовали реферальный код" });
        return;
      }

      // Check if referrer is not the same as current user
      if (referral.referrerId === userId) {
        res.status(400).json({ error: "Нельзя использовать собственный код" });
        return;
      }

      // Apply referral code to user
      await storage.updateReferredUser(promoCode, userId);

      // Give bonus to both users
      const REFERRAL_BONUS = "10"; // ₽10 bonus for new user
      
      const user = await storage.getUser(userId);
      if (user) {
        const newBalance = new Decimal(user.balance).plus(REFERRAL_BONUS).toString();
        await storage.updateUserBalance(userId, newBalance);
      }

      res.json({ success: true, message: "Промокод применён! Получен бонус ₽10" });
    } catch (error) {
      res.status(500).json({ error: "Ошибка при применении промокода" });
    }
  });

  app.get("/api/referrals/:userId/referrer", async (req, res) => {
    try {
      const referrerInfo = await storage.getReferrerInfo(req.params.userId);
      if (!referrerInfo) {
        res.status(404).json({ error: "Referrer not found" });
        return;
      }
      res.json(referrerInfo);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch referrer info" });
    }
  });

  // Admin endpoints
  app.get("/api/admin/users", async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      res.json(allUsers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  // Update user balance endpoint
  app.patch("/api/users/:userId/balance", async (req, res) => {
    try {
      const { balance } = req.body;
      if (!balance) {
        res.status(400).json({ error: "Balance is required" });
        return;
      }

      const updatedUser = await storage.updateUserBalance(req.params.userId, balance.toString());
      if (!updatedUser) {
        res.status(404).json({ error: "User not found" });
        return;
      }

      res.json(updatedUser);
    } catch (error) {
      console.error("Balance update error:", error);
      res.status(500).json({ error: "Failed to update balance" });
    }
  });

  return httpServer;
}
