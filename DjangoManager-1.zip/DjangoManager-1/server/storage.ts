import { db } from "./db";
import { users, deposits, withdrawals, gameTransactions, referrals, referralCommissions } from "@shared/schema";
import { type User, type InsertUser, type Deposit, type InsertDeposit, type Withdrawal, type InsertWithdrawal, type GameTransaction, type InsertGameTransaction, type Referral, type InsertReferral, type ReferralCommission, type InsertReferralCommission, type UpsertUser } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserBalance(userId: string, amount: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Deposits
  createDeposit(deposit: InsertDeposit): Promise<Deposit>;
  getDeposit(id: string): Promise<Deposit | undefined>;
  getUserDeposits(userId: string): Promise<Deposit[]>;
  updateDepositStatus(id: string, status: string): Promise<Deposit | undefined>;
  
  // Withdrawals
  createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal>;
  getWithdrawal(id: string): Promise<Withdrawal | undefined>;
  getUserWithdrawals(userId: string): Promise<Withdrawal[]>;
  updateWithdrawalStatus(id: string, status: string): Promise<Withdrawal | undefined>;
  
  // Game Transactions
  createGameTransaction(transaction: InsertGameTransaction): Promise<GameTransaction>;
  getUserGameTransactions(userId: string): Promise<GameTransaction[]>;

  // Referrals
  createReferral(referral: InsertReferral): Promise<Referral>;
  getReferralByCode(code: string): Promise<Referral | undefined>;
  getReferralByReferrerId(referrerId: string): Promise<Referral | undefined>;
  updateReferralStats(referralId: string, newReferredId: string): Promise<Referral | undefined>;
  getReferrals(): Promise<Referral[]>;
  updateReferralCommission(referralId: string, totalCommission: string): Promise<Referral | undefined>;
  updateReferredUser(promoCode: string, referredId: string): Promise<Referral | undefined>;
  getReferredUsers(referrerId: string): Promise<Array<{id: string; username: string; createdAt: Date; referredAt: Date}>>;
  getReferrerInfo(referredUserId: string): Promise<{id: string; username: string | null; promoCode: string; referredAt: Date} | null>;
  
  // Referral Commissions
  createReferralCommission(commission: InsertReferralCommission): Promise<ReferralCommission>;
  getReferralCommissions(referralId: string): Promise<ReferralCommission[]>;
  updateCommissionStatus(commissionId: string, status: string): Promise<ReferralCommission | undefined>;
}

export class DrizzleStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const user = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return user[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const user = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return user[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0]!;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, amount: string): Promise<User | undefined> {
    const result = await db.update(users).set({ balance: amount }).where(eq(users.id, userId)).returning();
    return result[0];
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  // Deposits
  async createDeposit(deposit: InsertDeposit): Promise<Deposit> {
    const result = await db.insert(deposits).values(deposit).returning();
    return result[0]!;
  }

  async getDeposit(id: string): Promise<Deposit | undefined> {
    const deposit = await db.select().from(deposits).where(eq(deposits.id, id)).limit(1);
    return deposit[0];
  }

  async getUserDeposits(userId: string): Promise<Deposit[]> {
    return db.select().from(deposits).where(eq(deposits.userId, userId)).orderBy(desc(deposits.createdAt));
  }

  async updateDepositStatus(id: string, status: string): Promise<Deposit | undefined> {
    const result = await db.update(deposits).set({ status, updatedAt: new Date() }).where(eq(deposits.id, id)).returning();
    return result[0];
  }

  // Withdrawals
  async createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal> {
    const result = await db.insert(withdrawals).values(withdrawal).returning();
    return result[0]!;
  }

  async getWithdrawal(id: string): Promise<Withdrawal | undefined> {
    const withdrawal = await db.select().from(withdrawals).where(eq(withdrawals.id, id)).limit(1);
    return withdrawal[0];
  }

  async getUserWithdrawals(userId: string): Promise<Withdrawal[]> {
    return db.select().from(withdrawals).where(eq(withdrawals.userId, userId)).orderBy(desc(withdrawals.createdAt));
  }

  async updateWithdrawalStatus(id: string, status: string): Promise<Withdrawal | undefined> {
    const result = await db.update(withdrawals).set({ status, updatedAt: new Date() }).where(eq(withdrawals.id, id)).returning();
    return result[0];
  }

  // Game Transactions
  async createGameTransaction(transaction: InsertGameTransaction): Promise<GameTransaction> {
    const result = await db.insert(gameTransactions).values(transaction).returning();
    return result[0]!;
  }

  async getUserGameTransactions(userId: string): Promise<GameTransaction[]> {
    return db.select().from(gameTransactions).where(eq(gameTransactions.userId, userId)).orderBy(desc(gameTransactions.createdAt));
  }

  // Referrals
  async createReferral(referral: InsertReferral): Promise<Referral> {
    const result = await db.insert(referrals).values(referral).returning();
    return result[0]!;
  }

  async getReferralByCode(code: string): Promise<Referral | undefined> {
    const referral = await db.select().from(referrals).where(eq(referrals.promoCode, code)).limit(1);
    return referral[0];
  }

  async getReferralByReferrerId(referrerId: string): Promise<Referral | undefined> {
    const referral = await db.select().from(referrals).where(eq(referrals.referrerId, referrerId)).limit(1);
    return referral[0];
  }

  async updateReferralStats(referralId: string, newReferredId: string): Promise<Referral | undefined> {
    const referral = await db.select().from(referrals).where(eq(referrals.id, referralId)).limit(1);
    if (!referral[0]) return undefined;

    const result = await db.update(referrals).set({
      referralCount: referral[0].referralCount + 1
    }).where(eq(referrals.id, referralId)).returning();
    return result[0];
  }

  // Referral Commissions
  async createReferralCommission(commission: InsertReferralCommission): Promise<ReferralCommission> {
    const result = await db.insert(referralCommissions).values(commission).returning();
    return result[0]!;
  }

  async getReferralCommissions(referralId: string): Promise<ReferralCommission[]> {
    return db.select().from(referralCommissions).where(eq(referralCommissions.referralId, referralId)).orderBy(desc(referralCommissions.createdAt));
  }

  async updateCommissionStatus(commissionId: string, status: string): Promise<ReferralCommission | undefined> {
    const result = await db.update(referralCommissions).set({ status }).where(eq(referralCommissions.id, commissionId)).returning();
    return result[0];
  }

  async getReferrals(): Promise<Referral[]> {
    return db.select().from(referrals);
  }

  async updateReferralCommission(referralId: string, totalCommission: string): Promise<Referral | undefined> {
    const result = await db.update(referrals).set({
      totalCommission: totalCommission
    }).where(eq(referrals.id, referralId)).returning();
    return result[0];
  }

  async updateReferredUser(promoCode: string, referredId: string): Promise<Referral | undefined> {
    const referral = await this.getReferralByCode(promoCode);
    if (!referral) return undefined;
    
    const result = await db.update(referrals).set({
      referredId
    }).where(eq(referrals.id, referral.id)).returning();
    return result[0];
  }

  async getReferredUsers(referrerId: string): Promise<Array<{id: string; username: string; createdAt: Date; referredAt: Date}>> {
    const results = await db.select({
      id: users.id,
      username: users.username,
      createdAt: users.createdAt,
      referredAt: referrals.createdAt
    }).from(referrals)
      .innerJoin(users, eq(users.id, referrals.referredId))
      .where(eq(referrals.referrerId, referrerId));
    return results as any;
  }

  async getReferrerInfo(referredUserId: string): Promise<{id: string; username: string | null; promoCode: string; referredAt: Date} | null> {
    const results = await db.select({
      id: users.id,
      username: users.username,
      promoCode: referrals.promoCode,
      referredAt: referrals.createdAt
    }).from(referrals)
      .innerJoin(users, eq(users.id, referrals.referrerId))
      .where(eq(referrals.referredId, referredUserId));
    return results[0] || null;
  }
}

export const storage = new DrizzleStorage();
