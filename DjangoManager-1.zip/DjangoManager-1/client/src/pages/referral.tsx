import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Copy, Share2, Users, Zap, TrendingUp } from "lucide-react";
import { toast } from "sonner";

export default function ReferralPage() {
  const [copied, setCopied] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);

  // Get user from localStorage (same as other pages)
  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user) {
      setUserId(JSON.parse(user).id);
    }
  }, []);

  const { data: referral } = useQuery({
    queryKey: [`/api/referrals/${userId}`],
    queryFn: async () => {
      const res = await fetch(`/api/referrals/${userId}`);
      if (!res.ok) throw new Error("Failed to fetch referral");
      return res.json();
    },
    enabled: !!userId,
  });

  const { data: commissions = [] } = useQuery({
    queryKey: [`/api/referrals/${userId}/commissions`],
    queryFn: async () => {
      if (!referral) return [];
      const res = await fetch(`/api/referrals/${userId}/commissions`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!referral,
  });

  const handleCreateReferral = async () => {
    if (!userId) return;
    try {
      const res = await fetch("/api/referrals/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ referrerId: userId }),
      });
      if (!res.ok) throw new Error();
      toast.success("Реферальный код создан!");
    } catch {
      toast.error("Ошибка при создании кода");
    }
  };

  const handleInviteShare = async () => {
    if (referral?.referralLink) {
      window.open(referral.referralLink, '_blank');
    } else {
      await handleCreateReferral();
    }
  };

  const handleCopyCode = () => {
    if (referral?.promoCode) {
      navigator.clipboard.writeText(referral.promoCode);
      setCopied(true);
      toast.success("Код скопирован!");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleCopyLink = () => {
    if (referral?.referralLink) {
      navigator.clipboard.writeText(referral.referralLink);
      setCopied(true);
      toast.success("Ссылка скопирована!");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = async () => {
    if (referral?.referralLink) {
      if (navigator.share) {
        try {
          await navigator.share({
            title: "SHOTO Referral",
            text: `Присоединись ко мне на SHOTO! Используй мой код: ${referral.promoCode}`,
            url: referral.referralLink,
          });
        } catch {
          handleCopyLink();
        }
      } else {
        handleCopyLink();
      }
    }
  };

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold font-orbitron mb-2">Реферальная программа</h1>
          <p className="text-muted-foreground">Зарабатывай 10% комиссии на депозиты рефералов</p>
        </div>

        {!referral ? (
          <Card className="border-purple-500/30 bg-purple-500/10">
            <CardHeader>
              <CardTitle>Пригласить друга</CardTitle>
              <CardDescription>Начни зарабатывать со своей реферальной ссылки</CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={handleInviteShare}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                data-testid="button-create-referral"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Пригласить друга
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Promo Code Card */}
            <Card className="border-green-500/30 bg-green-500/10">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Share2 className="w-5 h-5" />
                  Твой реферальный код
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-4 bg-black/50 rounded-lg border border-green-500/50 flex items-center justify-between" data-testid="display-promo-code">
                  <code className="text-xl font-bold text-green-400">{referral.promoCode}</code>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={handleCopyCode}
                    data-testid="button-copy-code"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="p-4 bg-black/50 rounded-lg border border-green-500/50 flex items-center justify-between text-sm" data-testid="display-referral-link">
                  <a 
                    href={referral.referralLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-green-400 truncate flex-1 hover:text-green-300 hover:underline cursor-pointer"
                    data-testid="link-referral"
                  >
                    {referral.referralLink}
                  </a>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={handleCopyLink}
                    data-testid="button-copy-link"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>

                <Button
                  onClick={handleShare}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                  data-testid="button-share-referral"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Поделиться
                </Button>
              </CardContent>
            </Card>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="border-blue-500/30 bg-blue-500/10">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Приглашённых</p>
                      <p className="text-3xl font-bold" data-testid="text-referral-count">{referral.referralCount}</p>
                    </div>
                    <Users className="w-8 h-8 text-blue-400 opacity-50" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-yellow-500/30 bg-yellow-500/10">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Комиссия</p>
                      <p className="text-2xl font-bold text-yellow-400" data-testid="text-total-commission">
                        ₽{parseFloat(referral.totalCommission).toFixed(2)}
                      </p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-yellow-400 opacity-50" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Commissions List */}
            {commissions.length > 0 && (
              <Card className="border-purple-500/30 bg-purple-500/10">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5" />
                    История комиссий
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {commissions.map((commission: any, index: number) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-black/50 rounded-lg border border-purple-500/30"
                        data-testid={`row-commission-${index}`}
                      >
                        <div>
                          <p className="text-sm text-muted-foreground">Депозит: ₽{parseFloat(commission.depositAmount).toFixed(2)}</p>
                          <p className="text-xs text-muted-foreground">{new Date(commission.createdAt).toLocaleString('ru-RU')}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-green-400">+₽{parseFloat(commission.commissionAmount).toFixed(2)}</p>
                          <p className="text-xs text-muted-foreground capitalize">{commission.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Info Card */}
            <Card className="border-blue-500/30 bg-blue-500/10">
              <CardHeader>
                <CardTitle>Как это работает?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <p>✅ Поделись своей ссылкой с друзьями</p>
                <p>✅ Твои друзья регистрируются по твоей ссылке</p>
                <p>✅ Когда они пополняют счёт, ты получаешь 10% комиссии</p>
                <p>✅ Комиссия добавляется на твой счёт автоматически</p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </Layout>
  );
}
