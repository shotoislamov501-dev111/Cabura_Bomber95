import Layout from "@/components/layout";
import { useLanguage } from "@/lib/language-context";
import { useBalance } from "@/lib/balance-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart3, Users, TrendingUp, Zap, Lock, Trash2, Unlock, Eye, X, User as UserIcon } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";

interface Transaction {
  id: string;
  type: "bet" | "win" | "deposit" | "withdraw";
  amount: number;
  date: string;
  description: string;
}

interface User {
  id: string;
  username: string;
  email: string;
  balance: number;
  status: "active" | "blocked";
  joinDate: string;
  totalBets?: number;
  totalWins?: number;
  winRate?: number;
  lastActivity?: string;
  transactions?: Transaction[];
  createdAt?: string;
}

export default function AdminPage() {
  const { language } = useLanguage();
  const { setBalance } = useBalance();
  const [, setLocation] = useLocation();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [fundAmount, setFundAmount] = useState("");
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'profile'>('all');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [myBalance, setMyBalance] = useState("");

  useEffect(() => {
    const accessGranted = localStorage.getItem("admin_access");
    if (!accessGranted) {
      setLocation("/");
    }

    // Fetch all users and current user from API
    const fetchData = async () => {
      try {
        const userId = localStorage.getItem("userId");
        
        // Fetch all users
        const res = await fetch("/api/admin/users");
        if (res.ok) {
          const data = await res.json();
          const formattedUsers: User[] = data.map((u: any) => ({
            id: u.id,
            username: u.username || u.email || u.id,
            email: u.email || "N/A",
            balance: parseFloat(u.balance) || 0,
            status: "active" as const,
            joinDate: u.createdAt ? new Date(u.createdAt).toISOString().split('T')[0] : "N/A",
            createdAt: u.createdAt,
          }));
          setUsers(formattedUsers);
        }

        // Fetch current user
        if (userId) {
          const userRes = await fetch(`/api/users/${userId}`);
          if (userRes.ok) {
            const userData = await userRes.json();
            setCurrentUser({
              id: userData.id,
              username: userData.username || userData.email || userData.id,
              email: userData.email || "N/A",
              balance: parseFloat(userData.balance) || 0,
              status: "active",
              joinDate: userData.createdAt ? new Date(userData.createdAt).toISOString().split('T')[0] : "N/A",
              createdAt: userData.createdAt,
            });
          }
        }
      } catch (error) {
        console.error("Failed to fetch data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    
    // If admin but no currentUser loaded, create a placeholder
    const timer = setTimeout(() => {
      if (!currentUser) {
        const userId = localStorage.getItem("userId");
        setCurrentUser({
          id: userId || "admin",
          username: "Admin",
          email: "admin@shoto.local",
          balance: 0,
          status: "active",
          joinDate: new Date().toISOString().split('T')[0],
        });
      }
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [setLocation, currentUser]);

  const handleBlockUser = (userId: string) => {
    setUsers(users.map(user => 
      user.id === userId 
        ? { ...user, status: user.status === "active" ? "blocked" : "active" }
        : user
    ));
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm(language === 'ru' ? 'Вы уверены? Это действие необратимо!' : 'Are you sure? This action cannot be undone!')) {
      setUsers(users.filter(user => user.id !== userId));
    }
  };

  const handleAddFunds = (userId: string, amount: number) => {
    if (amount <= 0) {
      alert(language === 'ru' ? 'Введите корректную сумму' : 'Enter a valid amount');
      return;
    }
    setUsers(users.map(user => 
      user.id === userId 
        ? { ...user, balance: user.balance + amount }
        : user
    ));
    setSelectedUser(selectedUser ? { ...selectedUser, balance: selectedUser.balance + amount } : null);
    setFundAmount("");
  };

  const handleRemoveFunds = (userId: string, amount: number) => {
    if (amount <= 0) {
      alert(language === 'ru' ? 'Введите корректную сумму' : 'Enter a valid amount');
      return;
    }
    setUsers(users.map(user => 
      user.id === userId 
        ? { ...user, balance: Math.max(0, user.balance - amount) }
        : user
    ));
    setSelectedUser(selectedUser ? { ...selectedUser, balance: Math.max(0, selectedUser.balance - amount) } : null);
    setFundAmount("");
  };

  const handleUpdateMyBalance = (amount: number, action: 'add' | 'remove') => {
    const numAmount = parseFloat(String(amount));
    if (!numAmount || numAmount <= 0 || isNaN(numAmount)) {
      alert(language === 'ru' ? 'Введите корректную сумму' : 'Enter a valid amount');
      return;
    }
    
    if (!currentUser) return;

    const newBalance = action === 'add' 
      ? currentUser.balance + numAmount 
      : Math.max(0, currentUser.balance - numAmount);

    setCurrentUser({
      ...currentUser,
      balance: newBalance,
    });
    
    // Update the global balance context so the top balance display updates
    setBalance(newBalance);
    
    setMyBalance("");
    alert(language === 'ru' 
      ? `Баланс: ${newBalance.toLocaleString('ru-RU')} ₽` 
      : `Balance: ${newBalance.toLocaleString('en-US')} ₽`);
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="glass-panel p-8 rounded-2xl">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-black font-orbitron text-white mb-2">
                {language === 'ru' ? 'Панель администратора' : 'Admin Panel'}
              </h1>
              <p className="text-muted-foreground">
                {language === 'ru' ? 'Управление платформой SHOTO' : 'Manage SHOTO platform'}
              </p>
            </div>
            <Zap className="w-12 h-12 text-green-400" />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-white/10">
          <Button
            onClick={() => setActiveTab('all')}
            className={`rounded-none border-b-2 transition-all ${
              activeTab === 'all'
                ? 'border-b-green-400 bg-transparent text-green-400'
                : 'border-b-transparent bg-transparent text-muted-foreground hover:text-white'
            }`}
          >
            {language === 'ru' ? 'Все игроки' : 'All Players'}
          </Button>
          <Button
            onClick={() => setActiveTab('profile')}
            className={`rounded-none border-b-2 transition-all ${
              activeTab === 'profile'
                ? 'border-b-blue-400 bg-transparent text-blue-400'
                : 'border-b-transparent bg-transparent text-muted-foreground hover:text-white'
            }`}
          >
            <UserIcon className="w-4 h-4 mr-2" />
            {language === 'ru' ? 'Мой профиль' : 'My Profile'}
          </Button>
        </div>

        {/* Stats Grid - Only show on "All Players" tab */}
        {activeTab === 'all' && <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="glass-panel p-6 rounded-2xl border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-1">
                  {language === 'ru' ? 'Активных игроков' : 'Active Players'}
                </p>
                <p className="text-3xl font-bold text-green-400">{users.filter(u => u.status === 'active').length}</p>
              </div>
              <Users className="w-10 h-10 text-green-400/30" />
            </div>
          </Card>

          <Card className="glass-panel p-6 rounded-2xl border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-1">
                  {language === 'ru' ? 'Общий оборот' : 'Total Turnover'}
                </p>
                <p className="text-3xl font-bold text-blue-400">₽{users.reduce((sum, u) => sum + u.balance, 0).toLocaleString('ru-RU')}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-blue-400/30" />
            </div>
          </Card>

          <Card className="glass-panel p-6 rounded-2xl border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-1">
                  {language === 'ru' ? 'Заблокировано' : 'Blocked'}
                </p>
                <p className="text-3xl font-bold text-orange-400">{users.filter(u => u.status === 'blocked').length}</p>
              </div>
              <BarChart3 className="w-10 h-10 text-orange-400/30" />
            </div>
          </Card>

          <Card className="glass-panel p-6 rounded-2xl border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-1">
                  {language === 'ru' ? 'Всего игроков' : 'Total Players'}
                </p>
                <p className="text-3xl font-bold text-purple-400">{users.length}</p>
              </div>
              <Zap className="w-10 h-10 text-purple-400/30" />
            </div>
          </Card>
        </div>}

        {/* My Profile Tab */}
        {activeTab === 'profile' && (
          <div className="space-y-6">
            <Card className="glass-panel p-8 rounded-2xl border-white/10">
              <div className="space-y-6">
                {currentUser ? (
                  <>
                    {/* Profile Header */}
                    <div className="flex items-center gap-6">
                      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-400 to-purple-600 flex items-center justify-center">
                        <UserIcon className="w-10 h-10 text-white" />
                      </div>
                      <div>
                        <h2 className="text-3xl font-bold font-orbitron text-white">{currentUser.username}</h2>
                        <p className="text-muted-foreground text-lg">Administrator</p>
                      </div>
                    </div>

                    {/* Profile Info Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <p className="text-xs text-muted-foreground mb-2">{language === 'ru' ? 'Email' : 'Email'}</p>
                        <p className="text-sm font-mono text-white break-all">{currentUser.email}</p>
                      </div>
                      <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <p className="text-xs text-muted-foreground mb-2">{language === 'ru' ? 'ID' : 'ID'}</p>
                        <p className="text-sm font-mono text-white break-all">{currentUser.id.slice(0, 12)}...</p>
                      </div>
                      <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <p className="text-xs text-muted-foreground mb-2">{language === 'ru' ? 'Дата создания' : 'Created'}</p>
                        <p className="text-sm text-white">{currentUser.joinDate}</p>
                      </div>
                      <div className="bg-gradient-to-br from-green-600/20 to-green-400/10 p-4 rounded-lg border border-green-400/20">
                        <p className="text-xs text-green-400 mb-2">{language === 'ru' ? 'Текущий баланс' : 'Current Balance'}</p>
                        <p className="text-2xl font-bold text-green-400">₽{currentUser.balance.toLocaleString('ru-RU')}</p>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">
                      {language === 'ru' ? 'Загружаем ваши данные...' : 'Loading your profile...'}
                    </p>
                  </div>
                )}

                {/* Balance Management */}
                {currentUser && (
                  <div className="bg-white/5 p-6 rounded-lg border border-white/10 space-y-4">
                    <h3 className="text-lg font-bold text-white font-orbitron">
                      {language === 'ru' ? 'Управление балансом' : 'Balance Management'}
                    </h3>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={myBalance}
                        onChange={(e) => setMyBalance(e.target.value)}
                        placeholder={language === 'ru' ? 'Сумма (₽)' : 'Amount (₽)'}
                        className="flex-1 bg-black/30 border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-green-500"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => {
                          console.log('Add button clicked, myBalance:', myBalance);
                          handleUpdateMyBalance(parseFloat(myBalance) || 0, 'add');
                        }}
                        className="flex-1 bg-green-600 hover:bg-green-700 h-10 font-bold"
                      >
                        {language === 'ru' ? '✓ Добавить' : '✓ Add'}
                      </Button>
                      <Button
                        onClick={() => {
                          console.log('Remove button clicked, myBalance:', myBalance);
                          handleUpdateMyBalance(parseFloat(myBalance) || 0, 'remove');
                        }}
                        className="flex-1 bg-red-600 hover:bg-red-700 h-10 font-bold"
                      >
                        {language === 'ru' ? '✗ Убрать' : '✗ Remove'}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>
        )}

        {/* Users Management - Only show on "All Players" tab */}
        {activeTab === 'all' && (
          <div className="glass-panel p-6 rounded-2xl space-y-6">
          <h2 className="text-2xl font-bold font-orbitron text-white">
            {language === 'ru' ? 'Управление игроками' : 'Player Management'}
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Ник' : 'Username'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Email' : 'Email'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Баланс' : 'Balance'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Статус' : 'Status'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Дата входа' : 'Joined'}</th>
                  <th className="px-4 py-3 text-left text-muted-foreground font-semibold">{language === 'ru' ? 'Действия' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="px-4 py-4 text-white font-mono font-bold">{user.username}</td>
                    <td className="px-4 py-4 text-muted-foreground text-xs">{user.email}</td>
                    <td className="px-4 py-4 text-green-400 font-bold">₽{user.balance.toLocaleString('ru-RU')}</td>
                    <td className="px-4 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                        user.status === 'active'
                          ? 'bg-green-600/20 text-green-400'
                          : 'bg-red-600/20 text-red-400'
                      }`}>
                        {user.status === 'active' 
                          ? (language === 'ru' ? 'Активен' : 'Active')
                          : (language === 'ru' ? 'Заблокирован' : 'Blocked')}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-muted-foreground text-xs">{user.joinDate}</td>
                    <td className="px-4 py-4">
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          onClick={() => setSelectedUser(user)}
                          className="bg-blue-600 hover:bg-blue-700 text-xs h-8"
                        >
                          <Eye className="w-3 h-3 mr-1" />
                          {language === 'ru' ? 'Просмотр' : 'View'}
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleBlockUser(user.id)}
                          className={user.status === 'active' 
                            ? 'bg-orange-600 hover:bg-orange-700 text-xs h-8'
                            : 'bg-green-600 hover:bg-green-700 text-xs h-8'}
                        >
                          {user.status === 'active' ? (
                            <>
                              <Lock className="w-3 h-3 mr-1" />
                              {language === 'ru' ? 'Блок' : 'Block'}
                            </>
                          ) : (
                            <>
                              <Unlock className="w-3 h-3 mr-1" />
                              {language === 'ru' ? 'Разб' : 'Unblock'}
                            </>
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteUser(user.id)}
                          className="bg-red-600 hover:bg-red-700 text-xs h-8"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {users.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                {language === 'ru' ? 'Нет игроков' : 'No players'}
              </p>
            </div>
          )}
        </div>
        )}
      </div>

      {/* User Details Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="glass-panel rounded-2xl max-w-2xl w-full max-h-96 overflow-y-auto p-6 border border-white/10 space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold font-orbitron text-white">{selectedUser.username}</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedUser(null)}
                className="text-muted-foreground hover:text-white"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* User Info Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                <p className="text-xs text-muted-foreground mb-1">{language === 'ru' ? 'Email' : 'Email'}</p>
                <p className="text-sm font-mono text-white">{selectedUser.email}</p>
              </div>
              <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                <p className="text-xs text-muted-foreground mb-1">{language === 'ru' ? 'Баланс' : 'Balance'}</p>
                <p className="text-sm font-bold text-green-400">₽{selectedUser.balance.toLocaleString('ru-RU')}</p>
              </div>
              <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                <p className="text-xs text-muted-foreground mb-1">{language === 'ru' ? 'Дата входа' : 'Join Date'}</p>
                <p className="text-sm text-white">{selectedUser.joinDate}</p>
              </div>
              <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                <p className="text-xs text-muted-foreground mb-1">{language === 'ru' ? 'Последняя активность' : 'Last Activity'}</p>
                <p className="text-sm text-white">{selectedUser.lastActivity}</p>
              </div>
            </div>

            {/* Statistics */}
            <div className="bg-white/5 p-4 rounded-lg border border-white/10 space-y-3">
              <h3 className="font-bold text-white">{language === 'ru' ? 'Статистика' : 'Statistics'}</h3>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-black/20 p-2 rounded text-center">
                  <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Ставок' : 'Bets'}</p>
                  <p className="text-lg font-bold text-blue-400">{selectedUser.totalBets}</p>
                </div>
                <div className="bg-black/20 p-2 rounded text-center">
                  <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Выигрышей' : 'Wins'}</p>
                  <p className="text-lg font-bold text-green-400">{selectedUser.totalWins}</p>
                </div>
                <div className="bg-black/20 p-2 rounded text-center">
                  <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Win Rate' : 'Win Rate'}</p>
                  <p className="text-lg font-bold text-yellow-400">{selectedUser.winRate}%</p>
                </div>
              </div>
            </div>

            {/* Recent Transactions */}
            {selectedUser.transactions && selectedUser.transactions.length > 0 && (
              <div className="bg-white/5 p-4 rounded-lg border border-white/10 space-y-3">
                <h3 className="font-bold text-white">{language === 'ru' ? 'Последние транзакции' : 'Recent Transactions'}</h3>
                <div className="space-y-2">
                  {selectedUser.transactions.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between text-xs bg-black/20 p-2 rounded">
                      <div>
                        <p className="text-white font-mono">{tx.description}</p>
                        <p className="text-muted-foreground text-xs">{tx.date}</p>
                      </div>
                      <p className={tx.amount > 0 ? 'text-green-400 font-bold' : 'text-red-400 font-bold'}>
                        {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString('ru-RU')}₽
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Funds Management */}
            <div className="bg-white/5 p-4 rounded-lg border border-white/10 space-y-3">
              <h3 className="font-bold text-white">{language === 'ru' ? 'Управление средствами' : 'Fund Management'}</h3>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={fundAmount}
                  onChange={(e) => setFundAmount(e.target.value)}
                  placeholder={language === 'ru' ? 'Сумма (₽)' : 'Amount (₽)'}
                  className="flex-1 bg-black/30 border border-white/10 rounded px-3 py-2 text-white text-sm focus:outline-none focus:border-green-500"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => handleAddFunds(selectedUser.id, parseFloat(fundAmount))}
                  disabled={!fundAmount}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-sm h-8"
                >
                  {language === 'ru' ? '+ Выдать' : '+ Add'}
                </Button>
                <Button
                  onClick={() => handleRemoveFunds(selectedUser.id, parseFloat(fundAmount))}
                  disabled={!fundAmount}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-sm h-8"
                >
                  {language === 'ru' ? '- Отобрать' : '- Remove'}
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-4">
              <Button
                onClick={() => {
                  handleBlockUser(selectedUser.id);
                  setSelectedUser(null);
                }}
                className={selectedUser.status === 'active' 
                  ? 'bg-orange-600 hover:bg-orange-700 flex-1'
                  : 'bg-green-600 hover:bg-green-700 flex-1'}
              >
                {selectedUser.status === 'active' 
                  ? (language === 'ru' ? 'Блокировать' : 'Block')
                  : (language === 'ru' ? 'Разблокировать' : 'Unblock')}
              </Button>
              <Button
                variant="destructive"
                onClick={() => {
                  handleDeleteUser(selectedUser.id);
                  setSelectedUser(null);
                }}
                className="flex-1 bg-red-600 hover:bg-red-700"
              >
                {language === 'ru' ? 'Удалить' : 'Delete'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
