import Layout from "@/components/layout";
import { useLanguage } from "@/lib/language-context";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Settings, Lock, Mail, User as UserIcon, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function SettingsPage() {
  const { language } = useLanguage();
  const [, setLocation] = useLocation();
  const [newUsername, setNewUsername] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [userEmail] = useState("cosmic.voyager@shoto.ru");
  const [successMessage, setSuccessMessage] = useState("");

  const handleChangeUsername = () => {
    if (!newUsername.trim()) {
      alert(language === 'ru' ? 'Введите новый ник' : 'Enter new username');
      return;
    }
    setSuccessMessage(language === 'ru' ? '✓ Ник успешно изменён!' : '✓ Username changed successfully!');
    setNewUsername("");
    setTimeout(() => setSuccessMessage(""), 3000);
  };

  const handleChangePassword = () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      alert(language === 'ru' ? 'Заполните все поля' : 'Fill all fields');
      return;
    }
    if (newPassword !== confirmPassword) {
      alert(language === 'ru' ? 'Пароли не совпадают' : 'Passwords do not match');
      return;
    }
    if (newPassword.length < 6) {
      alert(language === 'ru' ? 'Пароль должен быть минимум 6 символов' : 'Password must be at least 6 characters');
      return;
    }
    alert(language === 'ru' ? '✓ На вашу почту отправлено письмо для подтверждения смены пароля' : '✓ Confirmation email sent for password change');
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-8">
        {/* Header */}
        <div className="glass-panel p-8 rounded-2xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/profile")}
                className="text-muted-foreground hover:text-white"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-4xl font-black font-orbitron text-white">
                  {language === 'ru' ? 'Настройки' : 'Settings'}
                </h1>
                <p className="text-muted-foreground text-sm">{language === 'ru' ? 'Управляйте вашим аккаунтом' : 'Manage your account'}</p>
              </div>
            </div>
            <Settings className="w-12 h-12 text-purple-400" />
          </div>
        </div>

        {/* Success Message */}
        {successMessage && (
          <div className="glass-panel p-4 rounded-2xl border border-green-500/20 bg-green-500/10">
            <p className="text-green-400 font-bold">{successMessage}</p>
          </div>
        )}

        {/* Change Username */}
        <div className="glass-panel p-8 rounded-2xl space-y-6">
          <div>
            <h2 className="text-2xl font-bold font-orbitron text-white mb-2 flex items-center gap-2">
              <UserIcon className="w-6 h-6 text-blue-400" />
              {language === 'ru' ? 'Изменить ник' : 'Change Username'}
            </h2>
            <p className="text-muted-foreground text-sm">{language === 'ru' ? 'Ваше текущее имя: CosmicVoyager' : 'Your current username: CosmicVoyager'}</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-white mb-2">
                {language === 'ru' ? 'Новый ник' : 'New Username'}
              </label>
              <input
                type="text"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder={language === 'ru' ? 'Введите новый ник' : 'Enter new username'}
                className="w-full bg-black/30 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            <Button
              onClick={handleChangeUsername}
              className="w-full bg-blue-600 hover:bg-blue-700 h-10 font-bold"
            >
              {language === 'ru' ? 'Сохранить новый ник' : 'Save New Username'}
            </Button>
          </div>
        </div>

        {/* Change Password */}
        <div className="glass-panel p-8 rounded-2xl space-y-6">
          <div>
            <h2 className="text-2xl font-bold font-orbitron text-white mb-2 flex items-center gap-2">
              <Lock className="w-6 h-6 text-orange-400" />
              {language === 'ru' ? 'Изменить пароль' : 'Change Password'}
            </h2>
            <p className="text-muted-foreground text-sm">{language === 'ru' ? 'Укрепите безопасность вашего аккаунта' : 'Strengthen your account security'}</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-white mb-2">
                {language === 'ru' ? 'Текущий пароль' : 'Current Password'}
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder={language === 'ru' ? 'Введите текущий пароль' : 'Enter current password'}
                className="w-full bg-black/30 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-orange-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-white mb-2">
                {language === 'ru' ? 'Новый пароль' : 'New Password'}
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder={language === 'ru' ? 'Введите новый пароль' : 'Enter new password'}
                className="w-full bg-black/30 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-orange-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-white mb-2">
                {language === 'ru' ? 'Подтвердите пароль' : 'Confirm Password'}
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder={language === 'ru' ? 'Повторите новый пароль' : 'Repeat new password'}
                className="w-full bg-black/30 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-orange-500 transition-colors"
              />
            </div>

            <Button
              onClick={handleChangePassword}
              className="w-full bg-orange-600 hover:bg-orange-700 h-10 font-bold"
            >
              {language === 'ru' ? 'Изменить пароль' : 'Change Password'}
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              {language === 'ru' 
                ? '💌 Письмо для восстановления пароля будет отправлено на ' 
                : '💌 Password recovery email will be sent to '}
              <span className="text-blue-400 font-bold">{userEmail}</span>
            </p>
          </div>
        </div>

        {/* Account Info */}
        <div className="glass-panel p-8 rounded-2xl space-y-4">
          <h2 className="text-2xl font-bold font-orbitron text-white mb-4 flex items-center gap-2">
            <Mail className="w-6 h-6 text-green-400" />
            {language === 'ru' ? 'Информация аккаунта' : 'Account Information'}
          </h2>

          <div className="space-y-3">
            <div className="bg-black/20 p-4 rounded-lg border border-white/10">
              <p className="text-muted-foreground text-xs mb-1">{language === 'ru' ? 'Email' : 'Email'}</p>
              <p className="text-white font-mono font-bold">{userEmail}</p>
            </div>

            <div className="bg-black/20 p-4 rounded-lg border border-white/10">
              <p className="text-muted-foreground text-xs mb-1">{language === 'ru' ? 'Аккаунт создан' : 'Account Created'}</p>
              <p className="text-white font-mono">2024-01-15</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
