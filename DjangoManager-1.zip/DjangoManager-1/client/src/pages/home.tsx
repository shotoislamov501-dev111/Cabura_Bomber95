import { useState, useEffect } from "react";
import Layout from "@/components/layout";
import RocketGame from "@/components/rocket-game";
import BomberGame from "@/components/bomber-game";
import CoinGame from "@/components/coin-game";
import DiceGame from "@/components/dice-game";
import RouletteGame from "@/components/roulette-game";
import OnlineCounter from "@/components/online-counter";
import { useLanguage } from "@/lib/language-context";
import { MOCK_TRANSACTIONS } from "@/lib/mock-data";
import { Trophy, History, Activity, Rocket, Bomb, Coins, Dices, Zap, Users, TrendingUp, TrendingDown, LogIn, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";

const FIRST_NAMES = [
  "Иван", "Сергей", "Николай", "Александр", "Андрей", 
  "Виктор", "Алексей", "Павел", "Михаил", "Игорь",
  "Дмитрий", "Владимир", "Владислав", "Денис", "Артем",
  "Максим", "Евгений", "Юрий", "Валерий", "Олег"
];

const LAST_NAMES = [
  "Петров", "Сидоров", "Волков", "Соколов", "Лебедев",
  "Козлов", "Новиков", "Морозов", "Павлов", "Орлов",
  "Никитин", "Соснин", "Рыжов", "Кузнецов", "Белов",
  "Зайцев", "Смирнов", "Колесников", "Викторов", "Миронов"
];

function generateRandomGameHistory(count: number) {
  const history = [];
  for (let i = 0; i < count; i++) {
    const firstName = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
    const lastName = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
    const isWin = Math.random() > 0.4; // 60% chance of win
    const betAmount = Math.floor(Math.random() * 450) + 50; // 50-500 руб
    const multiplier = isWin ? (Math.random() * 3.5 + 1).toFixed(2) : 0;
    const winAmount = isWin ? (betAmount * parseFloat(multiplier as any)).toFixed(2) : 0;
    
    history.push({
      id: `${i}-${Date.now()}`,
      playerName: `${firstName} ${lastName}`,
      betAmount,
      winAmount: parseFloat(winAmount as any),
      multiplier: parseFloat(multiplier as any),
      isWin,
      game: Math.random() > 0.5 ? 'rocket' : 'bomber'
    });
  }
  return history;
}

function generatePlayerActivity(count: number) {
  const activity = [];
  const now = new Date();
  for (let i = 0; i < count; i++) {
    const firstName = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
    const lastName = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
    const isJoined = Math.random() > 0.5;
    const minutesAgo = Math.floor(Math.random() * 30);
    const time = new Date(now.getTime() - minutesAgo * 60000);
    const hours = time.getHours().toString().padStart(2, '0');
    const minutes = time.getMinutes().toString().padStart(2, '0');
    
    activity.push({
      id: `${i}-${Date.now()}`,
      playerName: `${firstName} ${lastName}`,
      isJoined,
      time: `${hours}:${minutes}`,
      minutesAgo
    });
  }
  return activity;
}

export default function Home() {
  const [selectedGame, setSelectedGame] = useState<'rocket' | 'bomber' | 'coin' | 'dice' | 'roulette'>('rocket');
  const [playerActivity, setPlayerActivity] = useState(generatePlayerActivity(5));
  const [gameHistory, setGameHistory] = useState(generateRandomGameHistory(8));
  const { language } = useLanguage();
  const winTransactions: any[] = [];

  // Update player activity and game histories dynamically
  useEffect(() => {
    const interval = setInterval(() => {
      // Add new random game result for other players
      const newHistory = generateRandomGameHistory(1);
      setGameHistory(prev => [newHistory[0], ...prev.slice(0, 7)]);
      // Add new player activity
      const newActivity = generatePlayerActivity(1);
      setPlayerActivity(prev => [newActivity[0], ...prev.slice(0, 4)]);
    }, 4000); // Update every 4 seconds
    return () => clearInterval(interval);
  }, []);

  return (
    <Layout>
      <div className="space-y-8">
        {/* Online Status */}
        <section className="max-w-6xl mx-auto">
          <OnlineCounter />
        </section>

        {/* Game Selection */}
        <section className="max-w-6xl mx-auto">
          <div className="flex gap-3 mb-6 flex-wrap">
            <Button
              onClick={() => setSelectedGame('rocket')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-orbitron font-bold transition-all ${
                selectedGame === 'rocket'
                  ? 'bg-blue-600 hover:bg-blue-700 shadow-[0_0_20px_rgba(59,130,246,0.5)]'
                  : 'bg-white/5 hover:bg-white/10 border border-white/10'
              }`}
            >
              <Rocket className="w-5 h-5" />
              <span>{language === 'ru' ? 'Ракета' : 'Rocket Crash'}</span>
            </Button>
            <Button
              onClick={() => setSelectedGame('bomber')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-orbitron font-bold transition-all ${
                selectedGame === 'bomber'
                  ? 'bg-orange-600 hover:bg-orange-700 shadow-[0_0_20px_rgba(249,115,22,0.5)]'
                  : 'bg-white/5 hover:bg-white/10 border border-white/10'
              }`}
            >
              <Bomb className="w-5 h-5" />
              <span>{language === 'ru' ? 'Бомбер' : 'Bomber'}</span>
            </Button>
            <Button
              onClick={() => setSelectedGame('coin')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-orbitron font-bold transition-all ${
                selectedGame === 'coin'
                  ? 'bg-yellow-600 hover:bg-yellow-700 shadow-[0_0_20px_rgba(234,179,8,0.5)]'
                  : 'bg-white/5 hover:bg-white/10 border border-white/10'
              }`}
            >
              <Coins className="w-5 h-5" />
              <span>{language === 'ru' ? 'Монетка' : 'Coin'}</span>
            </Button>
            <Button
              onClick={() => setSelectedGame('dice')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-orbitron font-bold transition-all ${
                selectedGame === 'dice'
                  ? 'bg-orange-600 hover:bg-orange-700 shadow-[0_0_20px_rgba(249,115,22,0.5)]'
                  : 'bg-white/5 hover:bg-white/10 border border-white/10'
              }`}
            >
              <Dices className="w-5 h-5" />
              <span>{language === 'ru' ? 'Кубики' : 'Dice'}</span>
            </Button>
            <Button
              onClick={() => setSelectedGame('roulette')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-orbitron font-bold transition-all ${
                selectedGame === 'roulette'
                  ? 'bg-orange-600 hover:bg-orange-700 shadow-[0_0_20px_rgba(249,115,22,0.5)]'
                  : 'bg-white/5 hover:bg-white/10 border border-white/10'
              }`}
            >
              <svg viewBox="0 0 100 100" className="w-5 h-5" fill="currentColor">
                <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
                <circle cx="50" cy="50" r="38" fill="none" stroke="currentColor" strokeWidth="2"/>
                <circle cx="50" cy="50" r="32" fill="none" stroke="currentColor" strokeWidth="2"/>
                <circle cx="50" cy="50" r="8" fill="currentColor"/>
                <line x1="50" y1="50" x2="50" y2="15" stroke="currentColor" strokeWidth="2"/>
              </svg>
              <span>{language === 'ru' ? 'Рулетка' : 'Roulette'}</span>
            </Button>
          </div>
        </section>

        {/* Game Section */}
        <section>
          {selectedGame === 'rocket' && <RocketGame />}
          {selectedGame === 'bomber' && <BomberGame />}
          {selectedGame === 'coin' && <CoinGame />}
          {selectedGame === 'dice' && <DiceGame />}
          {selectedGame === 'roulette' && <RouletteGame />}
        </section>

        {/* Recent Activity Section */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-6xl mx-auto">
          {/* Player Activity - Who Joined/Left */}
          <div className="glass-panel p-6 rounded-2xl">
            <div className="flex items-center gap-2 mb-4 text-blue-400">
              <Activity className="w-5 h-5" />
              <h3 className="font-bold font-orbitron">
                {language === 'ru' ? 'АКТИВНОСТЬ ИГРОКОВ' : 'PLAYER ACTIVITY'}
              </h3>
            </div>
            <div className="space-y-3">
              {playerActivity.map((item, i) => (
                <div
                  key={item.id}
                  data-testid={`activity-item-${i}`}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    item.isJoined
                      ? 'bg-cyan-500/10 border border-cyan-500/30 hover:bg-cyan-500/15'
                      : 'bg-purple-500/10 border border-purple-500/30 hover:bg-purple-500/15'
                  }`}
                >
                  <div className="flex items-center gap-3 flex-1">
                    <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                      item.isJoined ? 'bg-cyan-500/30' : 'bg-purple-500/30'
                    }`}>
                      {item.isJoined ? 
                        <LogIn className="w-5 h-5 text-cyan-400" /> :
                        <LogOut className="w-5 h-5 text-purple-400" />
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-white truncate">{item.playerName}</div>
                      <div className="text-xs text-muted-foreground">
                        {item.isJoined 
                          ? (language === 'ru' ? 'Зашел' : 'Joined')
                          : (language === 'ru' ? 'Вышел' : 'Left')
                        }
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-mono text-cyan-400">{item.time}</div>
                    <div className="text-xs text-muted-foreground">
                      {item.minutesAgo === 0 ? (language === 'ru' ? 'Сейчас' : 'Now') : `${item.minutesAgo} ${language === 'ru' ? 'мин' : 'min'}`}
                    </div>
                  </div>
                </div>
              ))}
              {playerActivity.length === 0 && (
                <p className="text-muted-foreground text-center py-4">
                  {language === 'ru' ? 'Нет активности' : 'No activity'}
                </p>
              )}
            </div>
          </div>

          {/* Game History */}
          <div className="glass-panel p-6 rounded-2xl">
            <div className="flex items-center gap-2 mb-4 text-cyan-400">
              <History className="w-5 h-5" />
              <h3 className="font-bold font-orbitron">
                {language === 'ru' ? 'ИСТОРИЯ ИГРОКОВ' : 'PLAYERS HISTORY'}
              </h3>
            </div>
            <div className="space-y-2">
              {gameHistory.map((item, i) => (
                <div
                  key={item.id}
                  data-testid={`history-item-${i}`}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    item.isWin
                      ? 'bg-green-500/10 border border-green-500/30 hover:bg-green-500/15'
                      : 'bg-red-500/10 border border-red-500/30 hover:bg-red-500/15'
                  }`}
                >
                  <div className="flex items-center gap-3 flex-1">
                    <div className={`flex items-center justify-center w-6 h-6 rounded-full ${
                      item.isWin ? 'bg-green-500/30' : 'bg-red-500/30'
                    }`}>
                      {item.isWin ? 
                        <TrendingUp className="w-4 h-4 text-green-400" /> :
                        <TrendingDown className="w-4 h-4 text-red-400" />
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-white truncate">{item.playerName}</div>
                      <div className="text-xs text-muted-foreground">
                        {item.game === 'rocket' ? (language === 'ru' ? 'Ракета' : 'Rocket') : (language === 'ru' ? 'Бомбер' : 'Bomber')}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground font-mono">₽{item.betAmount}</div>
                    <div className={`font-bold text-sm ${item.isWin ? 'text-green-400' : 'text-red-400'}`}>
                      {item.isWin ? `+₽${item.winAmount.toFixed(2)}` : `-₽${item.betAmount}`}
                    </div>
                    {item.isWin && <div className="text-xs text-yellow-400">{item.multiplier}x</div>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
