import { Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { useBalance } from "@/lib/balance-context";

export default function AuthPage() {
  const [referralCode, setReferralCode] = useState<string>("");
  const [, navigate] = useLocation();
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [registerUsername, setRegisterUsername] = useState("");
  const [registerEmail, setRegisterEmail] = useState("");
  const [registerPassword, setRegisterPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { setUserId } = useBalance();

  useEffect(() => {
    const code = localStorage.getItem("referralCode");
    if (code) {
      setReferralCode(code);
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/auth/email-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
        credentials: "include",
      });

      if (res.ok) {
        const data = await res.json();
        localStorage.setItem('userId', data.user.id);
        setUserId(data.user.id);
        toast.success("✓ " + data.message);
        navigate("/");
      } else {
        const error = await res.json();
        toast.error("✗ " + error.error);
      }
    } catch (error) {
      toast.error("✗ Ошибка входа");
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: registerUsername, email: registerEmail, password: registerPassword }),
        credentials: "include",
      });

      if (res.ok) {
        const data = await res.json();
        localStorage.setItem('userId', data.user.id);
        setUserId(data.user.id);
        toast.success("✓ " + data.message);
        setRegisterUsername("");
        setRegisterEmail("");
        setRegisterPassword("");
        navigate("/");
      } else {
        const error = await res.json();
        toast.error("✗ " + error.error);
      }
    } catch (error) {
      toast.error("✗ Ошибка регистрации");
    } finally {
      setLoading(false);
    }
  };

  const socialProviders = [
    {
      name: "Google",
      icon: (
        <svg className="w-5 h-5" viewBox="0 0 24 24">
          <path
            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            fill="#4285F4"
          />
          <path
            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            fill="#34A853"
          />
          <path
            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
            fill="#FBBC05"
          />
          <path
            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
            fill="#EA4335"
          />
        </svg>
      ),
    },
    {
      name: "Facebook",
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
      ),
    },
    {
      name: "VK",
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm3.4 13.5c.7 0 1.1-.2 1.5-.7 1-1.2 1.5-2.5 1.6-4.2H15c0 1-.3 1.8-1 2.3-.3.2-.7.4-1.2.4-1 0-1.8-.6-2.2-1.5-.2-.4-.3-.9-.3-1.4 0-.5.1-1 .3-1.4.4-.9 1.2-1.5 2.2-1.5.5 0 .9.2 1.2.4.7.5 1 1.3 1 2.3h2c-.1-1.7-.6-3-1.6-4.2-.4-.5-.8-.7-1.5-.7-1.5 0-2.8.7-3.5 2-.4.8-.6 1.7-.6 2.8s.2 2 .6 2.8c.7 1.3 2 2 3.5 2z" />
        </svg>
      ),
    },
  ];

  return (
    <div className="w-full min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo Area */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-tr from-primary to-secondary mb-6 shadow-[0_0_40px_rgba(118,75,162,0.5)]">
            <Rocket className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold font-orbitron text-white mb-3">SHOTO</h1>
          <p className="text-muted-foreground text-lg">Ваш путь на вершину космоса.</p>
        </div>

        <div className="glass-panel p-8 rounded-2xl">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6 bg-black/20">
              <TabsTrigger value="login">Вход</TabsTrigger>
              <TabsTrigger value="register">Регистрация</TabsTrigger>
            </TabsList>

            {/* LOGIN TAB */}
            <TabsContent value="login">
              <form className="space-y-4" onSubmit={handleLogin}>
                <div className="space-y-2">
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    placeholder="ваша@почта.ру"
                    className="bg-black/30 border-white/10"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    required
                    data-testid="input-login-email"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password">Пароль</Label>
                  <Input
                    id="login-password"
                    type="password"
                    placeholder="Ваш пароль"
                    className="bg-black/30 border-white/10"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    required
                    data-testid="input-login-password"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary/90 mt-4"
                  disabled={loading}
                  data-testid="button-login"
                >
                  {loading ? "Загрузка..." : "Войти"}
                </Button>
              </form>
            </TabsContent>

            {/* REGISTER TAB */}
            <TabsContent value="register">
              <form className="space-y-4" onSubmit={handleRegister}>
                <div className="space-y-2">
                  <Label htmlFor="register-username">Логин</Label>
                  <Input
                    id="register-username"
                    type="text"
                    placeholder="МойЛогин123"
                    className="bg-black/30 border-white/10"
                    value={registerUsername}
                    onChange={(e) => setRegisterUsername(e.target.value)}
                    required
                    data-testid="input-register-username"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-email">Email</Label>
                  <Input
                    id="register-email"
                    type="email"
                    placeholder="космос@почта.ру"
                    className="bg-black/30 border-white/10"
                    value={registerEmail}
                    onChange={(e) => setRegisterEmail(e.target.value)}
                    required
                    data-testid="input-register-email"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-password">Пароль</Label>
                  <Input
                    id="register-password"
                    type="password"
                    placeholder="Мой123Пароль"
                    className="bg-black/30 border-white/10"
                    value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)}
                    required
                    data-testid="input-register-password"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-secondary hover:bg-secondary/90 mt-4 text-black font-bold"
                  disabled={loading}
                  data-testid="button-register"
                >
                  {loading ? "Загрузка..." : "Создать акаунт"}
                </Button>
                {referralCode && (
                  <div className="text-xs text-center text-muted-foreground mt-4">
                    Используется реферальный код: <span className="text-purple-400 font-bold">{referralCode}</span>
                  </div>
                )}
              </form>
            </TabsContent>
          </Tabs>

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-white/10" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-[#1a1a2e] px-2 text-muted-foreground rounded-full">
                или войдите через
              </span>
            </div>
          </div>

          {/* Social Buttons */}
          <div className="space-y-2">
            {socialProviders.map((provider) => (
              <Button
                key={provider.name}
                onClick={() => {
                  if (provider.name === "Google") {
                    window.location.href = "/api/login";
                  } else {
                    toast.info(`${provider.name} вход будет доступен вскоре!`);
                  }
                }}
                className="w-full bg-white/5 hover:bg-white/10 text-white border border-white/20 flex items-center justify-center gap-2 py-3"
                data-testid={`button-${provider.name.toLowerCase()}-login`}
              >
                {provider.icon}
                <span>{provider.name}</span>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
