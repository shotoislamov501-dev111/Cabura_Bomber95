import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Rocket, Mail, LogOut, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import Layout from "@/components/layout";

interface User {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  balance: string;
}

export default function AuthSuccessPage() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [, navigate] = useLocation();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await fetch("/api/auth/user", { credentials: "include" });
        if (res.ok) {
          const userData = await res.json();
          setUser(userData);
        } else {
          navigate("/auth");
        }
      } catch (error) {
        console.error("Error fetching user:", error);
        navigate("/auth");
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [navigate]);

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin mb-4">
              <Rocket className="w-12 h-12 text-blue-500 mx-auto" />
            </div>
            <p className="text-white">Загрузка профиля...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!user) {
    return (
      <Layout>
        <div className="max-w-md mx-auto mt-10">
          <p className="text-red-500">Ошибка загрузки профиля</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <div className="glass-panel p-8 rounded-2xl mb-6">
          {/* Profile Header */}
          <div className="text-center mb-8">
            {user.profileImageUrl && (
              <img
                src={user.profileImageUrl}
                alt="Profile"
                className="w-24 h-24 rounded-full mx-auto mb-4 border-2 border-blue-500 shadow-lg"
              />
            )}
            <h1 className="text-3xl font-bold font-orbitron text-white mb-2">
              {user.firstName} {user.lastName}
            </h1>
            <p className="text-blue-300 flex items-center justify-center gap-2">
              <Mail className="w-4 h-4" />
              {user.email}
            </p>
          </div>

          {/* User Info Grid */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-white/5 p-4 rounded-lg border border-white/10">
              <p className="text-muted-foreground text-sm mb-1">User ID</p>
              <p className="text-white font-mono text-sm truncate">{user.id}</p>
            </div>
            <div className="bg-white/5 p-4 rounded-lg border border-white/10">
              <p className="text-muted-foreground text-sm mb-1">Баланс</p>
              <p className="text-green-400 font-bold text-lg">₽{user.balance}</p>
            </div>
          </div>

          {/* Welcome Message */}
          <div className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 p-4 rounded-lg border border-blue-500/30 mb-8">
            <p className="text-white text-center">
              ✨ Добро пожаловать в SHOTO! <br />
              <span className="text-sm text-muted-foreground">
                Ваш аккаунт успешно создан через Google
              </span>
            </p>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-4">
            <Button
              onClick={() => navigate("/")}
              className="bg-blue-600 hover:bg-blue-700 w-full flex items-center justify-center gap-2"
              data-testid="button-go-home"
            >
              <Home className="w-4 h-4" />
              На главную
            </Button>
            <Button
              onClick={() => window.location.href = "/api/logout"}
              className="bg-red-600 hover:bg-red-700 w-full flex items-center justify-center gap-2"
              variant="outline"
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4" />
              Выход
            </Button>
          </div>
        </div>

        {/* Info Card */}
        <div className="glass-panel p-6 rounded-2xl">
          <h2 className="text-xl font-bold font-orbitron text-white mb-4">
            Что дальше?
          </h2>
          <ul className="space-y-3 text-muted-foreground">
            <li className="flex gap-3">
              <span className="text-blue-400">✓</span>
              <span>Начните играть в Ракету или Бомбер на главной странице</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-400">✓</span>
              <span>Пополните баланс через Tinkoff (+79047275294)</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-400">✓</span>
              <span>Приглашайте друзей и получайте рефeral комиссии (10%)</span>
            </li>
            <li className="flex gap-3">
              <span className="text-blue-400">✓</span>
              <span>Выводите выигрыши на карту или телефон</span>
            </li>
          </ul>
        </div>
      </div>
    </Layout>
  );
}
