import Layout from "@/components/layout";
import { INITIAL_USER } from "@/lib/mock-data";
import { useLanguage } from "@/lib/language-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wallet, QrCode, Building2, AlertTriangle, Check } from "lucide-react";
import { useState } from "react";

export default function DepositPage() {
  const user = INITIAL_USER;
  const { language } = useLanguage();
  const [amount, setAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"tinkoff" | "card">("tinkoff");
  const [loading, setLoading] = useState(false);

  const TINKOFF_PHONE = "+79047275294";

  const handleDeposit = async () => {
    if (!amount) {
      alert(language === 'ru' ? "Введите сумму" : "Enter amount");
      return;
    }

    setLoading(true);
    try {
      // Call backend API to create deposit
      const response = await fetch("/api/deposits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          amount: parseFloat(amount),
          status: "pending",
          paymentMethod: paymentMethod,
          tinkoffPhone: TINKOFF_PHONE,
        }),
      });

      if (response.ok) {
        const deposit = await response.json();
        alert(
          language === 'ru'
            ? `Заявка на пополнение на ₽${amount} создана. Переводите деньги на ${TINKOFF_PHONE}`
            : `Deposit request for ₽${amount} created. Send money to ${TINKOFF_PHONE}`
        );
        setAmount("");
      } else {
        alert(language === 'ru' ? "Ошибка при создании заявки" : "Error creating deposit");
      }
    } catch (error) {
      alert(language === 'ru' ? "Ошибка подключения" : "Connection error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="glass-panel p-8 rounded-2xl">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-4xl font-black font-orbitron text-white mb-2">
                {language === 'ru' ? 'Пополнение баланса' : 'Deposit Funds'}
              </h1>
              <p className="text-muted-foreground">
                {language === 'ru' ? 'Пополните ваш баланс через Tinkoff' : 'Top up your balance via Tinkoff'}
              </p>
            </div>
            <div className="text-right">
              <p className="text-muted-foreground text-sm mb-1">{language === 'ru' ? 'Текущий баланс:' : 'Balance:'}</p>
              <p className="text-4xl font-bold text-green-400 font-mono">
                ₽{user.balance.toLocaleString('ru-RU')}
              </p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="deposit" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6 bg-black/20">
            <TabsTrigger value="deposit">{language === 'ru' ? 'Пополнить' : 'Deposit'}</TabsTrigger>
            <TabsTrigger value="methods">{language === 'ru' ? 'Способы оплаты' : 'Payment Methods'}</TabsTrigger>
          </TabsList>

          {/* Deposit Tab */}
          <TabsContent value="deposit">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Deposit Form */}
              <div className="lg:col-span-2 glass-panel p-6 rounded-2xl space-y-6">
                {/* Payment Method Selection */}
                <div>
                  <h3 className="text-lg font-bold font-orbitron text-white mb-4">
                    {language === 'ru' ? 'Выберите способ оплаты' : 'Payment Method'}
                  </h3>
                  <div className="space-y-3">
                    <div
                      onClick={() => setPaymentMethod("tinkoff")}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        paymentMethod === "tinkoff"
                          ? "bg-blue-600/20 border-blue-500"
                          : "bg-white/5 border-white/10 hover:border-white/20"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Wallet className="w-5 h-5 text-blue-400" />
                          <div>
                            <p className="font-bold text-white">Tinkoff</p>
                            <p className="text-xs text-muted-foreground">{TINKOFF_PHONE}</p>
                          </div>
                        </div>
                        {paymentMethod === "tinkoff" && (
                          <Check className="w-5 h-5 text-green-400" />
                        )}
                      </div>
                    </div>

                    <div
                      onClick={() => setPaymentMethod("card")}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all opacity-50 ${
                        paymentMethod === "card"
                          ? "bg-purple-600/20 border-purple-500"
                          : "bg-white/5 border-white/10"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Building2 className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="font-bold text-white">{language === 'ru' ? 'Карта' : 'Card'} (coming soon)</p>
                            <p className="text-xs text-muted-foreground">{language === 'ru' ? 'Скоро будет доступно' : 'Will be available soon'}</p>
                          </div>
                        </div>
                        {paymentMethod === "card" && (
                          <Check className="w-5 h-5 text-green-400" />
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Amount Selection */}
                <div>
                  <h3 className="text-lg font-bold font-orbitron text-white mb-4">
                    {language === 'ru' ? 'Сумма пополнения' : 'Amount'}
                  </h3>
                  <div className="space-y-4">
                    <div className="relative">
                      <Label htmlFor="amount">{language === 'ru' ? 'Сумма (₽)' : 'Amount (₽)'}</Label>
                      <div className="relative mt-2">
                        <span className="absolute left-3 top-3.5 text-primary font-bold text-lg">₽</span>
                        <Input
                          id="amount"
                          type="number"
                          placeholder="10"
                          min="10"
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          className="pl-10 bg-black/30 border-white/10 h-12 text-lg"
                        />
                      </div>
                    </div>

                    {/* Quick Amount Buttons */}
                    <div className="grid grid-cols-4 gap-2">
                      {[10, 100, 500, 1000].map((amt) => (
                        <Button
                          key={amt}
                          variant="outline"
                          onClick={() => setAmount(amt.toString())}
                          className="bg-white/5 border-white/10 hover:bg-white/10"
                        >
                          ₽{amt.toLocaleString('ru-RU')}
                        </Button>
                      ))}
                    </div>

                    {amount && (
                      <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">{language === 'ru' ? 'К пополнению:' : 'To deposit:'}</span>
                          <span className="text-green-400 font-bold text-lg">
                            ₽{parseFloat(amount).toLocaleString('ru-RU')}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Instructions */}
                <div className="bg-blue-500/10 border border-blue-500/30 p-4 rounded-lg space-y-3">
                  <div className="flex gap-3">
                    <QrCode className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-blue-200">
                      <p className="font-bold mb-2">{language === 'ru' ? 'Инструкция:' : 'Instructions:'}</p>
                      <ol className="list-decimal list-inside space-y-1">
                        <li>{language === 'ru' ? 'Откройте приложение Tinkoff' : 'Open the Tinkoff app'}</li>
                        <li>{language === 'ru' ? 'Переведите деньги на номер' : 'Send money to'} {TINKOFF_PHONE}</li>
                        <li>{language === 'ru' ? 'Указав сумму' : 'Specifying amount'} ₽{amount || '___'}</li>
                        <li>{language === 'ru' ? 'Баланс пополнится автоматически' : 'Balance will be replenished automatically'}</li>
                      </ol>
                    </div>
                  </div>
                </div>

                {/* Deposit Button */}
                <Button
                  onClick={handleDeposit}
                  disabled={!amount || loading}
                  className="w-full bg-green-600 hover:bg-green-700 h-12 text-lg font-bold"
                >
                  {loading
                    ? (language === 'ru' ? 'Обработка...' : 'Processing...')
                    : (language === 'ru' ? `Пополнить на ₽${amount || '0'}` : `Deposit ₽${amount || '0'}`)}
                </Button>
              </div>

              {/* Info Sidebar */}
              <div className="space-y-4">
                <Card className="glass-panel p-6 rounded-2xl border-white/10">
                  <h4 className="font-bold text-white mb-3 font-orbitron">
                    {language === 'ru' ? 'О пополнении' : 'About Deposit'}
                  </h4>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>✓ {language === 'ru' ? 'Мгновенный перевод' : 'Instant transfer'}</p>
                    <p>✓ {language === 'ru' ? 'Без комиссии' : 'No fees'}</p>
                    <p>✓ {language === 'ru' ? 'Безопасно' : 'Secure'}</p>
                  </div>
                </Card>

                <Card className="glass-panel p-6 rounded-2xl border-white/10 bg-purple-600/10 border-purple-500/30">
                  <h4 className="font-bold text-white mb-3 font-orbitron">
                    {language === 'ru' ? 'Номер Tinkoff' : 'Tinkoff Number'}
                  </h4>
                  <p className="text-2xl font-bold text-primary font-mono mb-2">{TINKOFF_PHONE}</p>
                  <p className="text-xs text-muted-foreground">
                    {language === 'ru' ? 'Используйте этот номер для перевода' : 'Use this number to send money'}
                  </p>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Payment Methods Info Tab */}
          <TabsContent value="methods">
            <div className="glass-panel p-6 rounded-2xl space-y-4">
              <h3 className="text-lg font-bold font-orbitron text-white">
                {language === 'ru' ? 'Способы оплаты' : 'Payment Methods'}
              </h3>
              
              <div className="bg-white/5 p-4 rounded-lg border border-white/10 space-y-3">
                <div>
                  <h4 className="font-bold text-white mb-2">🏦 Tinkoff (Активно)</h4>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ru'
                      ? 'Переведите деньги на номер Tinkoff +79047275294. Пополнение происходит мгновенно после получения платежа.'
                      : 'Send money to Tinkoff +79047275294. Top-up happens instantly after payment is received.'}
                  </p>
                </div>
              </div>

              <div className="bg-white/5 p-4 rounded-lg border border-white/10 opacity-50 space-y-3">
                <div>
                  <h4 className="font-bold text-white mb-2">💳 Card (Coming Soon)</h4>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ru'
                      ? 'В ближайшее время мы добавим возможность пополнения через карту.'
                      : 'Soon we will add the ability to top up via card.'}
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
