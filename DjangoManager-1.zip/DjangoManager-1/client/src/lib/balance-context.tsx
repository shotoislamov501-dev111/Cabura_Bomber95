import React, { createContext, useContext, useState, useEffect } from 'react';

interface BalanceContextType {
  balance: number;
  setBalance: (balance: number) => void;
  updateBalance: (amount: number) => void;
  userId: string | null;
  setUserId: (id: string | null) => void;
}

const BalanceContext = createContext<BalanceContextType | undefined>(undefined);

export function BalanceProvider({ children }: { children: React.ReactNode }) {
  const [balance, setBalanceState] = useState(0);
  const [userId, setUserId] = useState<string | null>(null);

  // Initialize userId from localStorage on mount, or create a guest ID
  useEffect(() => {
    let savedUserId = localStorage.getItem('userId');
    if (!savedUserId) {
      // Create a guest ID if not logged in
      savedUserId = `guest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('userId', savedUserId);
    }
    setUserId(savedUserId);
    
    // Load initial balance from localStorage or API
    const savedBalance = localStorage.getItem(`balance_${savedUserId}`);
    if (savedBalance) {
      setBalanceState(parseFloat(savedBalance));
    }
  }, []);

  // Poll for balance updates every 5 seconds when userId is set (less aggressive)
  useEffect(() => {
    if (!userId) return;

    const fetchBalance = async () => {
      try {
        const res = await fetch(`/api/users/${userId}`);
        if (res.ok) {
          const user = await res.json();
          const dbBalance = parseFloat(user.balance) || 0;
          const localBalance = parseFloat(localStorage.getItem(`balance_${userId}`) || '0');
          
          // Only update if DB balance is higher (user was created in DB)
          if (dbBalance > 0) {
            setBalanceState(dbBalance);
            localStorage.setItem(`balance_${userId}`, dbBalance.toString());
          }
        }
      } catch (error) {
        console.error('Failed to fetch balance:', error);
      }
    };

    // Fetch balance on mount
    fetchBalance();
    const interval = setInterval(fetchBalance, 5000);
    return () => clearInterval(interval);
  }, [userId]);

  const setBalance = (newBalance: number) => {
    const safeBalance = Math.max(0, newBalance);
    setBalanceState(safeBalance);
    if (userId) {
      localStorage.setItem(`balance_${userId}`, safeBalance.toString());
    }
  };

  const updateBalance = (amount: number) => {
    setBalance(balance + amount);
  };

  return (
    <BalanceContext.Provider value={{ balance, setBalance, updateBalance, userId, setUserId }}>
      {children}
    </BalanceContext.Provider>
  );
}

export function useBalance() {
  const context = useContext(BalanceContext);
  if (context === undefined) {
    throw new Error('useBalance must be used within BalanceProvider');
  }
  return context;
}
