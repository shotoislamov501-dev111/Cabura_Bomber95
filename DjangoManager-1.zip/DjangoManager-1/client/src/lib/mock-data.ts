export interface SHOTOUserProfile {
  id: string;
  username: string;
  email: string;
  balance: number;
  totalEarned: number;
  createdAt: string;
}

export interface SHOTOTransaction {
  id: string;
  userId: string;
  amount: number;
  type: 'deposit' | 'withdrawal' | 'earning';
  status: 'pending' | 'completed' | 'rejected';
  description: string;
  createdAt: string;
  updatedAt: string;
}

export const INITIAL_USER: SHOTOUserProfile = {
  id: 'user_1',
  username: 'CosmicVoyager',
  email: 'cosmic.voyager@shoto.ru',
  balance: 50,
  totalEarned: 250050,
  createdAt: '2024-01-15',
};

export const MOCK_TRANSACTIONS: SHOTOTransaction[] = [
  {
    id: 'txn_1',
    userId: 'user_1',
    amount: 25000,
    type: 'earning',
    status: 'completed',
    description: 'Rocket game win - 2.5x multiplier',
    createdAt: '2024-05-20 14:30',
    updatedAt: '2024-05-20 14:30',
  },
  {
    id: 'txn_2',
    userId: 'user_1',
    amount: 10000,
    type: 'deposit',
    status: 'pending',
    description: 'Deposit via credit card',
    createdAt: '2024-05-20 10:15',
    updatedAt: '2024-05-20 10:15',
  },
  {
    id: 'txn_3',
    userId: 'user_1',
    amount: 50000,
    type: 'deposit',
    status: 'completed',
    description: 'Deposit via bank transfer',
    createdAt: '2024-05-19 09:15',
    updatedAt: '2024-05-19 09:15',
  },
  {
    id: 'txn_4',
    userId: 'user_1',
    amount: 120000,
    type: 'earning',
    status: 'completed',
    description: 'Rocket game win - 12x multiplier',
    createdAt: '2024-05-18 22:00',
    updatedAt: '2024-05-18 22:00',
  },
  {
    id: 'txn_5',
    userId: 'user_1',
    amount: 30000,
    type: 'withdrawal',
    status: 'rejected',
    description: 'Withdrawal rejected - insufficient verification',
    createdAt: '2024-05-17 15:45',
    updatedAt: '2024-05-17 16:00',
  },
  {
    id: 'txn_6',
    userId: 'user_1',
    amount: 55050,
    type: 'earning',
    status: 'completed',
    description: 'Rocket game win - 5.5x multiplier',
    createdAt: '2024-05-16 18:20',
    updatedAt: '2024-05-16 18:20',
  },
];

export const GAME_CONFIG = {
  minBet: 10,
  maxBet: 1000,
  speed: 1.05,
};

export const TRANSACTION_TYPE_LABELS = {
  deposit: 'Пополнение SHOTO',
  withdrawal: 'Вывод из SHOTO',
  earning: 'Заработок в SHOTO',
};

export const TRANSACTION_STATUS_LABELS = {
  pending: 'Ожидание',
  completed: 'Завершено',
  rejected: 'Отклонено',
};
