import { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/lib/language-context';
import { useBalance } from '@/lib/balance-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

const ROULETTE_NUMBERS = Array.from({ length: 37 }, (_, i) => i);

export default function RouletteGame() {
  const [status, setStatus] = useState<'idle' | 'spinning' | 'result'>('idle');
  const [betAmount, setBetAmount] = useState(10);
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [selectedColor, setSelectedColor] = useState<'red' | 'black' | null>(null);
  const [rotation, setRotation] = useState(0);
  const [resultNumber, setResultNumber] = useState<number | null>(null);
  const [isWin, setIsWin] = useState(false);
  const [multiplier, setMultiplier] = useState(0);
  const { language } = useLanguage();
  const { balance: userBalance, updateBalance, userId } = useBalance();

  const getNumberColor = (num: number): 'red' | 'black' | 'green' => {
    if (num === 0) return 'green';
    const redNumbers = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
    return redNumbers.includes(num) ? 'red' : 'black';
  };

  const handleSpin = async () => {
    if (!selectedNumber && !selectedColor) {
      toast.error(language === 'ru' ? 'Выберите число или цвет' : 'Select a number or color');
      return;
    }

    if (userBalance < betAmount) {
      toast.error(language === 'ru' ? 'Недостаточно средств' : 'Insufficient balance');
      return;
    }

    updateBalance(-betAmount);

    try {
      await fetch('/api/game-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          game: 'roulette',
          betAmount: betAmount.toString(),
          status: 'loss',
        }),
      });
    } catch (error) {
      console.error('Failed to record bet:', error);
    }

    setStatus('spinning');
    const spins = Math.random() * 720 + 1440;
    let currentRotation = rotation + spins;
    setRotation(currentRotation);

    setTimeout(() => {
      const normalizedRotation = currentRotation % 360;
      const segmentIndex = Math.floor(normalizedRotation / (360 / 37));
      const winNumber = ROULETTE_NUMBERS[segmentIndex];
      const winColor = getNumberColor(winNumber);
      
      let won = false;
      let winMult = 0;

      if (selectedNumber === winNumber) {
        won = true;
        winMult = 36;
      } else if (selectedColor && selectedColor === winColor) {
        won = true;
        winMult = 2;
      }

      setResultNumber(winNumber);
      setIsWin(won);
      setMultiplier(winMult);
      setStatus('result');

      if (won) {
        const winAmount = betAmount * winMult;
        updateBalance(winAmount);

        try {
          fetch('/api/game-transactions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId,
              game: 'roulette',
              betAmount: betAmount.toString(),
              winAmount: winAmount.toString(),
              multiplier: winMult.toFixed(2),
              status: 'win',
            }),
          });
        } catch (error) {
          console.error('Failed to record win:', error);
        }

        toast.success(language === 'ru' ? `✓ ВЫИГРЫШ! +₽${winAmount.toFixed(2)}` : `✓ WIN! +₽${winAmount.toFixed(2)}`);
      } else {
        toast.error(language === 'ru' ? `✗ ПРОИГРЫШ! -₽${betAmount.toFixed(2)}` : `✗ LOSS! -₽${betAmount.toFixed(2)}`);
      }
    }, 3000);
  };

  const handlePlayAgain = () => {
    setStatus('idle');
    setResultNumber(null);
    setIsWin(false);
    setMultiplier(0);
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="relative min-h-[480px] rounded-3xl overflow-hidden flex flex-col p-8" style={{background: 'linear-gradient(135deg, #0f0f1a 0%, #1a1524 50%, #0f1620 100%)'}}>
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-600/5 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 flex-1 flex items-center justify-center">
          {status === 'idle' ? (
            <div className="text-center w-full">
              <motion.div
                animate={{ rotateZ: [0, -10, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                className="mb-6 flex justify-center"
              >
                <svg viewBox="0 0 100 100" className="w-20 h-20" style={{ filter: 'drop-shadow(0 0 20px rgba(147,51,234,0.6))' }}>
                  <circle cx="50" cy="50" r="45" fill="none" stroke="#d4af37" strokeWidth="3"/>
                  <circle cx="50" cy="50" r="38" fill="none" stroke="#dc3545" strokeWidth="2"/>
                  <circle cx="50" cy="50" r="32" fill="none" stroke="#1a1a1a" strokeWidth="2"/>
                  <circle cx="50" cy="50" r="8" fill="#d4af37"/>
                  <line x1="50" y1="50" x2="50" y2="15" stroke="#dc3545" strokeWidth="2"/>
                </svg>
              </motion.div>
              <h2 className="text-5xl font-black font-orbitron text-white mb-3 drop-shadow-lg">РУЛЕТКА</h2>
              <p className="text-gray-300 mb-8 text-base font-semibold">
                {language === 'ru' ? 'Выберите число или цвет' : 'Select a number or color'}
              </p>

              <div className="flex flex-col items-center gap-6 mb-6">
                <div className="flex gap-3">
                  <button
                    onClick={() => { setSelectedColor('red'); setSelectedNumber(null); }}
                    disabled={status !== 'idle'}
                    className={`px-6 py-2 rounded-lg font-bold transition-all text-white text-sm ${
                      selectedColor === 'red'
                        ? 'bg-red-600 shadow-lg border-2 border-red-400'
                        : 'bg-red-900/30 border-2 border-red-500/30 hover:bg-red-900/50'
                    }`}
                  >
                    🔴 {language === 'ru' ? 'КРАСНОЕ' : 'RED'}
                  </button>
                  <button
                    onClick={() => { setSelectedColor('black'); setSelectedNumber(null); }}
                    disabled={status !== 'idle'}
                    className={`px-6 py-2 rounded-lg font-bold transition-all text-white text-sm ${
                      selectedColor === 'black'
                        ? 'bg-gray-700 shadow-lg border-2 border-gray-400'
                        : 'bg-gray-900/40 border-2 border-gray-600/30 hover:bg-gray-900/60'
                    }`}
                  >
                    ⚫ {language === 'ru' ? 'ЧЁРНОЕ' : 'BLACK'}
                  </button>
                </div>

                <div className="w-full max-w-xl">
                  <p className="text-xs font-bold text-cyan-300 mb-2 text-center">🎲 {language === 'ru' ? 'Число' : 'Number'}</p>
                  <div className="grid grid-cols-8 gap-1 bg-black/30 p-3 rounded-lg border-2 border-purple-500/30 max-h-24 overflow-y-auto">
                    {ROULETTE_NUMBERS.map((num) => (
                      <button
                        key={num}
                        onClick={() => { setSelectedNumber(num); setSelectedColor(null); }}
                        disabled={status !== 'idle'}
                        className={`py-1 rounded text-xs font-bold transition-all ${
                          selectedNumber === num
                            ? 'bg-gradient-to-br from-cyan-400 to-blue-400 text-black shadow-lg border border-cyan-200'
                            : getNumberColor(num) === 'red'
                            ? 'bg-red-700/60 border border-red-500/40 hover:bg-red-700 text-white'
                            : getNumberColor(num) === 'black'
                            ? 'bg-gray-700/60 border border-gray-500/40 hover:bg-gray-700 text-white'
                            : 'bg-green-700/60 border border-green-500/40 hover:bg-green-700 text-white'
                        }`}
                      >
                        {num}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="w-full max-w-xs">
                  <label className="block text-xs font-bold text-cyan-300 mb-1">💎 {language === 'ru' ? 'Ставка (₽)' : 'Bet (₽)'}</label>
                  <Input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(Math.max(1, parseInt(e.target.value) || 1))}
                    className="bg-black/40 border-2 border-purple-500/40 text-white font-bold text-center text-base rounded-lg"
                    disabled={status !== 'idle'}
                  />
                </div>
              </div>

              <Button
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold shadow-lg text-sm px-8 py-3 rounded-xl"
                onClick={handleSpin}
                disabled={!selectedNumber && !selectedColor}
              >
                {language === 'ru' ? 'НАЧАТЬ' : 'START'}
              </Button>
            </div>
          ) : (
            <div style={{ perspective: '1200px' }} className="flex items-center justify-center">
              <div className="relative">
                <motion.div
                  animate={{ rotateZ: status === 'spinning' ? 3600 : rotation }}
                  transition={{ duration: status === 'spinning' ? 4.5 : 0.5, ease: status === 'spinning' ? 'easeOut' : 'linear' }}
                  className="relative w-80 h-80"
                >
                  <svg viewBox="0 0 400 400" className="w-full h-full drop-shadow-[0_0_60px_rgba(147,51,234,0.4)]">
                    <defs>
                      <linearGradient id="rimGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style={{ stopColor: '#d4af37', stopOpacity: 1 }} />
                        <stop offset="100%" style={{ stopColor: '#aa8c2c', stopOpacity: 1 }} />
                      </linearGradient>
                      <radialGradient id="centerGrad" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" style={{ stopColor: '#e0b0ff', stopOpacity: 0.3 }} />
                        <stop offset="100%" style={{ stopColor: '#0f0f1a', stopOpacity: 1 }} />
                      </radialGradient>
                    </defs>
                    
                    <circle cx="200" cy="200" r="195" fill="url(#rimGradient)" stroke="#ffffff" strokeWidth="2" opacity="0.8"/>
                    
                    {ROULETTE_NUMBERS.map((num) => {
                      const angle = (num / 37) * 360;
                      const startAngle = angle - 4.87;
                      const endAngle = angle + 4.87;
                      const startRad = startAngle * Math.PI / 180;
                      const endRad = endAngle * Math.PI / 180;
                      
                      const x3 = 200 + 150 * Math.cos(startRad);
                      const y3 = 200 + 150 * Math.sin(startRad);
                      const x4 = 200 + 185 * Math.cos(startRad);
                      const y4 = 200 + 185 * Math.sin(startRad);
                      const x5 = 200 + 150 * Math.cos(endRad);
                      const y5 = 200 + 150 * Math.sin(endRad);
                      const x6 = 200 + 185 * Math.cos(endRad);
                      const y6 = 200 + 185 * Math.sin(endRad);
                      
                      const largeArc = endAngle - startAngle > 180 ? 1 : 0;
                      const pathData = `M ${x3} ${y3} L ${x4} ${y4} A 185 185 0 ${largeArc} 1 ${x6} ${y6} L ${x5} ${y5} A 150 150 0 ${largeArc} 0 ${x3} ${y3} Z`;
                      
                      const color = getNumberColor(num);
                      const fillColor = color === 'red' ? '#dc3545' : color === 'black' ? '#1a1a1a' : '#1ead6b';
                      
                      const textAngle = angle * Math.PI / 180;
                      const textX = 200 + 120 * Math.cos(textAngle - Math.PI/2);
                      const textY = 200 + 120 * Math.sin(textAngle - Math.PI/2);
                      
                      return (
                        <g key={num}>
                          <path d={pathData} fill={fillColor} stroke="#d4af37" strokeWidth="1" opacity="0.9"/>
                          <text x={textX} y={textY} textAnchor="middle" dy="0.3em" fill="#ffffff" fontSize="13" fontWeight="900" fontFamily="system-ui">
                            {num}
                          </text>
                        </g>
                      );
                    })}
                    
                    <circle cx="200" cy="200" r="40" fill="url(#centerGrad)" stroke="#d4af37" strokeWidth="2"/>
                    <circle cx="200" cy="200" r="25" fill="#0f0f1a" stroke="#d4af37" strokeWidth="1" opacity="0.5"/>
                  </svg>
                  
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-3">
                    <motion.div
                      animate={{ y: [0, -6, 0] }}
                      transition={{ duration: 0.6, repeat: Infinity }}
                      className="w-0 h-0 border-l-5 border-r-5 border-t-8 border-l-transparent border-r-transparent border-t-cyan-400"
                    ></motion.div>
                  </div>
                </motion.div>
              </div>
            </div>
          )}
        </div>

        {status === 'result' && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="relative z-10 text-center mt-6 p-6 bg-gradient-to-r from-purple-900/40 via-blue-900/40 to-purple-900/40 rounded-xl border border-purple-500/30 backdrop-blur-sm"
          >
            <h3 className={`text-5xl font-black font-orbitron mb-3 drop-shadow-lg ${isWin ? 'text-transparent bg-clip-text bg-gradient-to-r from-green-300 to-cyan-300' : 'text-red-400'}`}>
              {isWin ? (language === 'ru' ? '✨ ПОБЕДА ✨' : '✨ WIN ✨') : (language === 'ru' ? '• ПРОИГРЫШ •' : '• LOSS •')}
            </h3>
            <div className="flex items-center justify-center gap-4 mb-4">
              <div className="px-6 py-3 rounded-lg font-bold text-base border-2 border-cyan-400/50 bg-gray-900/60">
                <p className="text-cyan-300 text-xs mb-1">{language === 'ru' ? 'Число' : 'Number'}</p>
                <p className="text-xl text-white">{resultNumber}</p>
              </div>
              {isWin && (
                <div className="px-6 py-3 rounded-lg font-bold text-base bg-gradient-to-r from-yellow-500 to-orange-500 shadow-lg">
                  <p className="text-xs text-yellow-100 mb-1">{language === 'ru' ? 'Выигрыш' : 'x'}</p>
                  <p className="text-xl text-white">×{multiplier}</p>
                </div>
              )}
            </div>
            <Button
              size="sm"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold shadow-lg px-6 py-2 rounded-lg text-sm"
              onClick={handlePlayAgain}
            >
              {language === 'ru' ? 'ЕЩЕ' : 'AGAIN'}
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
