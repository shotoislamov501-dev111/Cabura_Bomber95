import { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/lib/language-context';
import { useBalance } from '@/lib/balance-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Zap } from 'lucide-react';
import { toast } from 'sonner';

const MULTIPLIERS = [1, 2, 1.5, 3, 1.2, 2.5, 1, 4, 1.8, 2, 1.5, 3.5];

export default function SpinGame() {
  const [status, setStatus] = useState<'idle' | 'spinning' | 'result'>('idle');
  const [betAmount, setBetAmount] = useState(10);
  const [rotation, setRotation] = useState(0);
  const [selectedMultiplier, setSelectedMultiplier] = useState<number | null>(null);
  const [isWin, setIsWin] = useState(false);
  const { language } = useLanguage();
  const { balance: userBalance, updateBalance, userId } = useBalance();

  const handleSpin = async () => {
    if (userBalance < betAmount) {
      toast.error(language === 'ru' ? 'Недостаточно средств' : 'Insufficient balance');
      return;
    }

    updateBalance(-betAmount);

    try {
      await fetch('/api/game-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          game: 'spin',
          betAmount: betAmount.toString(),
          status: 'loss',
        }),
      });
    } catch (error) {
      console.error('Failed to record bet:', error);
    }

    setStatus('spinning');
    const spins = Math.random() * 360 + 720;
    let currentRotation = rotation + spins;
    setRotation(currentRotation);

    setTimeout(() => {
      const normalizedRotation = currentRotation % 360;
      const segmentIndex = Math.floor(normalizedRotation / (360 / MULTIPLIERS.length));
      const multiplier = MULTIPLIERS[segmentIndex];
      const win = multiplier > 1;

      setSelectedMultiplier(multiplier);
      setIsWin(win);
      setStatus('result');

      if (win) {
        const winAmount = betAmount * multiplier;
        updateBalance(winAmount);

        try {
          fetch('/api/game-transactions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId,
              game: 'spin',
              betAmount: betAmount.toString(),
              winAmount: winAmount.toString(),
              multiplier: multiplier.toFixed(2),
              status: 'win',
            }),
          });
        } catch (error) {
          console.error('Failed to record win:', error);
        }

        toast.success(language === 'ru' ? `✓ ВЫИГРЫШ! x${multiplier.toFixed(2)}` : `✓ WIN! x${multiplier.toFixed(2)}`);
      } else {
        toast.error(language === 'ru' ? `✗ ПРОИГРЫШ!` : `✗ LOSS!`);
      }
    }, 3000);
  };

  const handlePlayAgain = () => {
    setStatus('idle');
    setSelectedMultiplier(null);
    setIsWin(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
      {/* Game Display */}
      <div className="lg:col-span-2 relative min-h-[500px] glass-card rounded-2xl overflow-hidden flex flex-col p-6" style={{background: 'linear-gradient(135deg, #2a1810 0%, #3d2415 50%, #4a2c1a 100%)'}}>
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(249,115,22,0.1)_0%,_transparent_70%)]" />
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 4, repeat: Infinity }}
            className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(249,115,22,0.05)_0%,_transparent_70%)]"
          />
        </div>

        <div className="relative z-10 flex-1 flex items-center justify-center">
          {status === 'idle' ? (
            <div className="text-center">
              <motion.div animate={{ y: [0, -10, 0] }} transition={{ duration: 2, repeat: Infinity }}>
                <Zap className="w-20 h-20 mx-auto text-orange-400 mb-4 drop-shadow-[0_0_20px_rgba(249,115,22,0.6)]" />
              </motion.div>
              <h2 className="text-4xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-orange-300 to-yellow-300 mb-3 drop-shadow-[0_0_10px_rgba(249,115,22,0.4)]">СПИН</h2>
              <p className="text-orange-300 mb-8 text-lg">
                {language === 'ru' ? 'Попадите на больший коэффициент' : 'Land on higher multipliers'}
              </p>
              <Button
                size="lg"
                className="bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white font-bold shadow-[0_0_30px_rgba(249,115,22,0.5)]"
                onClick={handleSpin}
              >
                {language === 'ru' ? 'Начать игру' : 'Start Game'}
              </Button>
            </div>
          ) : (
            <div className="relative w-48 h-48">
              <svg className="w-full h-full" viewBox="0 0 200 200" style={{ filter: 'drop-shadow(0 0 30px rgba(249,115,22,0.6))' }}>
                {MULTIPLIERS.map((mult, i) => {
                  const angle = (i / MULTIPLIERS.length) * 360;
                  const startAngle = angle;
                  const endAngle = ((i + 1) / MULTIPLIERS.length) * 360;
                  const colors = [
                    '#ec4899', '#f472b6', '#fb7185', '#f87171',
                    '#fca5a5', '#fecaca', '#fef3c7', '#fde047',
                    '#facc15', '#eab308', '#ca8a04', '#f59e0b'
                  ];

                  return (
                    <motion.g
                      key={i}
                      animate={{ rotate: status === 'spinning' ? [rotation, rotation + 360] : rotation }}
                      transition={{ duration: status === 'spinning' ? 3 : 0, ease: status === 'spinning' ? 'easeOut' : 'linear' }}
                      style={{ transformOrigin: '100px 100px', transformBox: 'fill-box' }}
                    >
                      <path
                        d={`M 100 100 L ${100 + 90 * Math.cos((startAngle - 90) * Math.PI / 180)} ${100 + 90 * Math.sin((startAngle - 90) * Math.PI / 180)} A 90 90 0 ${endAngle - startAngle > 180 ? 1 : 0} 1 ${100 + 90 * Math.cos((endAngle - 90) * Math.PI / 180)} ${100 + 90 * Math.sin((endAngle - 90) * Math.PI / 180)} Z`}
                        fill={colors[i]}
                        stroke="#000"
                        strokeWidth="2"
                      />
                      <text
                        x={100 + 60 * Math.cos(((startAngle + endAngle) / 2 - 90) * Math.PI / 180)}
                        y={100 + 60 * Math.sin(((startAngle + endAngle) / 2 - 90) * Math.PI / 180)}
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="font-black font-orbitron text-black"
                        fontSize="12"
                        fill="#000"
                      >
                        {mult}x
                      </text>
                    </motion.g>
                  );
                })}
                <circle cx="100" cy="100" r="10" fill="#ffffff" stroke="#000" strokeWidth="2" />
              </svg>
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-2 text-2xl font-black">▼</div>
            </div>
          )}
        </div>

        {status === 'result' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative z-10 text-center mt-8">
            <h3 className={`text-5xl font-black font-orbitron mb-2 drop-shadow-lg ${isWin ? 'text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500' : 'text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-pink-500'}`}>
              {isWin ? (language === 'ru' ? 'ПОБЕДА!' : 'WIN!') : (language === 'ru' ? 'ПРОИГРЫШ!' : 'LOSS!')}
            </h3>
            <p className="text-2xl text-orange-300 mb-6 font-bold">x{selectedMultiplier?.toFixed(2)}</p>
            <Button
              size="lg"
              className="bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white font-bold"
              onClick={handlePlayAgain}
            >
              {language === 'ru' ? 'Ещё раз' : 'Play Again'}
            </Button>
          </motion.div>
        )}
      </div>

      {/* Settings Panel */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between min-h-[500px] bg-gradient-to-b from-orange-950/30 to-orange-950/30 border border-orange-500/30 shadow-[0_0_30px_rgba(249,115,22,0.2)]">
        <div>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-300">
                {language === 'ru' ? 'СТАВКА' : 'STAKE'}
              </h2>
              <p className="text-sm text-emerald-400 font-mono mt-2 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]">₽{userBalance.toFixed(2)}</p>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex justify-between text-sm">
              <span className="text-orange-300">{language === 'ru' ? 'Размер ставки' : 'Bet Amount'}</span>
              <span className="text-orange-100 font-bold">₽{betAmount}</span>
            </div>
            <Input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Number(e.target.value))}
              className="h-12 text-lg font-mono bg-black/40 border border-orange-500/50 focus:border-orange-400 text-center text-orange-200 placeholder-orange-500/50"
              disabled={status !== 'idle'}
              min="1"
            />

            <div className="space-y-2 text-xs text-orange-300 mt-8 bg-orange-950/30 p-4 rounded-lg border border-orange-500/20">
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Макс выигрыш' : 'Max Win'}</span>
                <span className="text-orange-100 font-bold">x4.0</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Мин выигрыш' : 'Min Win'}</span>
                <span className="text-orange-100 font-bold">x1.2</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Коэф. убытка' : 'Lose Multiplier'}</span>
                <span className="text-red-400 font-bold">x0</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Шанс выигрыша' : 'Win Chance'}</span>
                <span className="text-orange-100 font-bold">~67%</span>
              </div>
            </div>
          </div>
        </div>

        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Button
            size="lg"
            className="w-full h-14 text-lg font-black font-orbitron uppercase bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 shadow-[0_0_30px_rgba(249,115,22,0.6)]"
            onClick={handleSpin}
            disabled={status !== 'idle'}
          >
            {status === 'idle' ? (language === 'ru' ? '⚡ КРУТИТЬ!' : '⚡ SPIN!') : (language === 'ru' ? '⏳ КРУЖИТСЯ...' : '⏳ SPINNING...')}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
