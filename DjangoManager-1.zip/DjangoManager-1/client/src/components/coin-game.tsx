import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/lib/language-context';
import { useBalance } from '@/lib/balance-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Coins } from 'lucide-react';
import { toast } from 'sonner';

export default function CoinGame() {
  const [status, setStatus] = useState<'idle' | 'flipping' | 'result'>('idle');
  const [betAmount, setBetAmount] = useState(10);
  const [selectedSide, setSelectedSide] = useState<'heads' | 'tails'>('heads');
  const [result, setResult] = useState<'heads' | 'tails' | null>(null);
  const [isWin, setIsWin] = useState(false);
  const [coinRotation, setCoinRotation] = useState(0);
  const { t, language } = useLanguage();
  const { balance: userBalance, updateBalance, userId } = useBalance();

  const handleFlip = async () => {
    // Check balance
    if (userBalance < betAmount) {
      toast.error(language === 'ru' ? 'Недостаточно средств' : 'Insufficient balance');
      return;
    }

    // Deduct bet from balance
    updateBalance(-betAmount);

    // Record bet on server
    try {
      await fetch('/api/game-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          game: 'coin',
          betAmount: betAmount.toString(),
          status: 'loss',
        }),
      });
    } catch (error) {
      console.error('Failed to record bet:', error);
    }

    // Flip animation
    setStatus('flipping');
    let rotation = 0;
    const flipInterval = setInterval(() => {
      rotation += 45;
      setCoinRotation(rotation);
    }, 50);

    // Determine result after 2 seconds
    setTimeout(() => {
      clearInterval(flipInterval);
      const coinResult = Math.random() > 0.5 ? 'heads' : 'tails';
      const win = coinResult === selectedSide;

      setResult(coinResult);
      setIsWin(win);
      setCoinRotation(win ? 0 : 180);
      setStatus('result');

      if (win) {
        const winAmount = betAmount * 2;
        updateBalance(winAmount);

        // Record win on server
        try {
          fetch('/api/game-transactions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId,
              game: 'coin',
              betAmount: betAmount.toString(),
              winAmount: winAmount.toString(),
              multiplier: '2.00',
              status: 'win',
            }),
          });
        } catch (error) {
          console.error('Failed to record win:', error);
        }

        toast.success(language === 'ru' ? `✓ ВЫИГРЫШ! +₽${winAmount.toFixed(2)}` : `✓ WIN! +₽${winAmount.toFixed(2)}`);
      } else {
        toast.error(language === 'ru' ? `✗ ПРОИГРЫШ! -₽${betAmount.toFixed(2)}` : `✗ LOSS! -₽${betAmount.toFixed(2)}`);
      }
    }, 2000);
  };

  const handlePlayAgain = () => {
    setStatus('idle');
    setResult(null);
    setIsWin(false);
    setCoinRotation(0);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
      {/* Game Display */}
      <div className="lg:col-span-2 relative min-h-[500px] glass-card rounded-2xl overflow-hidden flex flex-col p-6" style={{background: 'linear-gradient(135deg, #2a1810 0%, #3d2415 50%, #4a2c1a 100%)'}}>
        <div className="absolute inset-0 z-0">
          {/* Animated background */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(249,115,22,0.1)_0%,_transparent_70%)]" />
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 4, repeat: Infinity }}
            className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(249,115,22,0.05)_0%,_transparent_70%)]"
          />
        </div>

        <div className="relative z-10 flex-1 flex items-center justify-center">
          {status === 'idle' ? (
            <div className="text-center">
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Coins className="w-20 h-20 mx-auto text-orange-400 mb-4 drop-shadow-[0_0_20px_rgba(249,115,22,0.6)]" />
              </motion.div>
              <h2 className="text-4xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-orange-300 to-yellow-300 mb-3 drop-shadow-[0_0_10px_rgba(249,115,22,0.4)]">МОНЕТКА</h2>
              <p className="text-orange-300 mb-8 text-lg">
                {language === 'ru' ? 'Угадайте сторону монеты' : 'Guess the coin side'}
              </p>
              <Button
                size="lg"
                className="bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white font-bold shadow-[0_0_30px_rgba(249,115,22,0.5)]"
                onClick={handleFlip}
              >
                {language === 'ru' ? 'Начать игру' : 'Start Game'}
              </Button>
            </div>
          ) : (
            <div style={{ perspective: '1200px' }} className="flex items-center justify-center">
              <motion.div
                animate={{ rotateY: coinRotation, scale: status === 'flipping' ? [1, 1.15, 1.15] : 1 }}
                transition={{ duration: status === 'flipping' ? 2 : 0.5 }}
                style={{
                  width: '160px',
                  height: '160px',
                  transformStyle: 'preserve-3d',
                  position: 'relative',
                }}
              >
                {/* Heads Side - Eagle */}
                <div
                  style={{
                    position: 'absolute',
                    width: '100%',
                    height: '100%',
                    backfaceVisibility: 'hidden',
                    transformStyle: 'preserve-3d',
                  }}
                  className="rounded-full bg-gradient-to-br from-yellow-300 via-yellow-200 to-orange-300 flex flex-col items-center justify-center shadow-[0_0_50px_rgba(249,115,22,0.8),0_0_100px_rgba(251,146,60,0.5)] border-4 border-yellow-200/50"
                >
                  <svg className="w-20 h-20 mb-2" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    {/* Eagle head */}
                    <circle cx="50" cy="35" r="15" fill="#8B4513" stroke="#654321" strokeWidth="2"/>
                    {/* Eagle beak */}
                    <path d="M 65 35 L 80 32 L 65 38 Z" fill="#DAA520" stroke="#8B6914" strokeWidth="1"/>
                    {/* Left wing */}
                    <path d="M 35 45 Q 20 40 15 60 Q 20 55 35 55 Z" fill="#654321" stroke="#3D2817" strokeWidth="1.5"/>
                    {/* Right wing */}
                    <path d="M 65 45 Q 80 40 85 60 Q 80 55 65 55 Z" fill="#654321" stroke="#3D2817" strokeWidth="1.5"/>
                    {/* Eye */}
                    <circle cx="57" cy="32" r="2.5" fill="#FFD700"/>
                    {/* Eagle body */}
                    <ellipse cx="50" cy="65" rx="12" ry="18" fill="#654321" stroke="#3D2817" strokeWidth="1.5"/>
                  </svg>
                  <div className="text-xs font-bold text-orange-900 uppercase">
                    {language === 'ru' ? 'Орёл' : 'Heads'}
                  </div>
                </div>

                {/* Tails Side - Number 1 */}
                <div
                  style={{
                    position: 'absolute',
                    width: '100%',
                    height: '100%',
                    backfaceVisibility: 'hidden',
                    transformStyle: 'preserve-3d',
                    transform: 'rotateY(180deg)',
                  }}
                  className="rounded-full bg-gradient-to-br from-orange-400 via-orange-300 to-amber-300 flex flex-col items-center justify-center shadow-[0_0_50px_rgba(249,115,22,0.8),0_0_100px_rgba(251,146,60,0.5)] border-4 border-orange-200/50"
                >
                  <div className="text-7xl font-black text-orange-900 mb-2 drop-shadow-lg">1</div>
                  <div className="text-xs font-bold text-orange-900 uppercase">
                    {language === 'ru' ? 'Решка' : 'Tails'}
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </div>

        {status === 'result' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative z-10 text-center mt-8"
          >
            <h3 className={`text-5xl font-black font-orbitron mb-2 drop-shadow-lg ${isWin ? 'text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500' : 'text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-pink-500'}`}>
              {isWin ? (language === 'ru' ? 'ПОБЕДА!' : 'WIN!') : (language === 'ru' ? 'ПРОИГРЫШ!' : 'LOSS!')}
            </h3>
            <p className="text-lg text-orange-300 mb-6 font-bold">
              {result === 'heads' ? (language === 'ru' ? 'Орёл' : 'Heads') : (language === 'ru' ? 'Решка' : 'Tails')}
            </p>
            <Button
              size="lg"
              className="bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white font-bold"
              onClick={handlePlayAgain}
            >
              {language === 'ru' ? 'Ещё раз' : 'Play Again'}
            </Button>
          </motion.div>
        )}
      </div>

      {/* Settings Panel */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between min-h-[500px] bg-gradient-to-b from-orange-950/30 to-orange-950/30 border border-orange-500/30 shadow-[0_0_30px_rgba(249,115,22,0.2)]">
        <div>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-300">
                {language === 'ru' ? 'СТАВКА' : 'STAKE'}
              </h2>
              <p className="text-sm text-emerald-400 font-mono mt-2 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]">₽{userBalance.toFixed(2)}</p>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex justify-between text-sm">
              <span className="text-orange-300">{language === 'ru' ? 'Размер ставки' : 'Bet Amount'}</span>
              <span className="text-orange-100 font-bold">₽{betAmount}</span>
            </div>
            <Input 
              type="number" 
              value={betAmount} 
              onChange={(e) => setBetAmount(Number(e.target.value))}
              className="h-12 text-lg font-mono bg-black/40 border border-orange-500/50 focus:border-orange-400 text-center text-orange-200 placeholder-orange-500/50"
              disabled={status !== 'idle'}
              min="1"
            />

            <div className="space-y-3 mt-6">
              <p className="text-sm font-bold text-orange-300">{language === 'ru' ? 'Выберите сторону' : 'Pick a side'}</p>
              <div className="grid grid-cols-2 gap-2">
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => setSelectedSide('heads')}
                    disabled={status !== 'idle'}
                    className={`w-full h-12 font-bold transition-all ${
                      selectedSide === 'heads'
                        ? 'bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 shadow-[0_0_20px_rgba(249,115,22,0.5)]'
                        : 'bg-orange-600/30 hover:bg-orange-600/50 border border-orange-500/30'
                    }`}
                  >
                    👑 {language === 'ru' ? 'Орёл' : 'Heads'}
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => setSelectedSide('tails')}
                    disabled={status !== 'idle'}
                    className={`w-full h-12 font-bold transition-all ${
                      selectedSide === 'tails'
                        ? 'bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 shadow-[0_0_20px_rgba(249,115,22,0.5)]'
                        : 'bg-orange-600/30 hover:bg-orange-600/50 border border-orange-500/30'
                    }`}
                  >
                    🪙 {language === 'ru' ? 'Решка' : 'Tails'}
                  </Button>
                </motion.div>
              </div>
            </div>

            <div className="space-y-2 text-xs text-orange-300 mt-8 bg-orange-950/30 p-4 rounded-lg border border-orange-500/20">
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Вероятность' : 'Probability'}</span>
                <span className="text-orange-100 font-bold">50%</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Коэффициент' : 'Multiplier'}</span>
                <span className="text-orange-100 font-bold">2x</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Возможный выигрыш' : 'Possible Win'}</span>
                <span className="text-emerald-400 font-bold">₽{(betAmount * 2).toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Button
            size="lg"
            className="w-full h-14 text-lg font-black font-orbitron uppercase bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 shadow-[0_0_30px_rgba(249,115,22,0.6)]"
            onClick={handleFlip}
            disabled={status !== 'idle'}
          >
            {status === 'idle' ? (language === 'ru' ? '🎲 КРУТИ!' : '🎲 FLIP!') : (language === 'ru' ? '⏳ ВРАЩЕНИЕ...' : '⏳ FLIPPING...')}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
