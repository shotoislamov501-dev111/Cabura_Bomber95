import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/lib/language-context';
import { useBalance } from '@/lib/balance-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dices } from 'lucide-react';
import { toast } from 'sonner';

export default function DiceGame() {
  const [status, setStatus] = useState<'idle' | 'rolling' | 'result'>('idle');
  const [betAmount, setBetAmount] = useState(10);
  const [selectedSide, setSelectedSide] = useState<'over' | 'under'>('over');
  const [dice1, setDice1] = useState(1);
  const [dice2, setDice2] = useState(1);
  const [total, setTotal] = useState(2);
  const [isWin, setIsWin] = useState(false);
  const [dice1Rotation, setDice1Rotation] = useState(0);
  const [dice2Rotation, setDice2Rotation] = useState(0);
  const { t, language } = useLanguage();
  const { balance: userBalance, updateBalance, userId } = useBalance();

  const handleRoll = async () => {
    // Check balance
    if (userBalance < betAmount) {
      toast.error(language === 'ru' ? 'Недостаточно средств' : 'Insufficient balance');
      return;
    }

    // Deduct bet from balance
    updateBalance(-betAmount);

    // Record bet on server
    try {
      await fetch('/api/game-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          game: 'dice',
          betAmount: betAmount.toString(),
          status: 'loss',
        }),
      });
    } catch (error) {
      console.error('Failed to record bet:', error);
    }

    // Rolling animation
    setStatus('rolling');
    let rotation1 = 0;
    let rotation2 = 0;
    const rollInterval = setInterval(() => {
      rotation1 += 60;
      rotation2 -= 60;
      setDice1Rotation(rotation1);
      setDice2Rotation(rotation2);
    }, 50);

    // Determine result after 2 seconds
    setTimeout(() => {
      clearInterval(rollInterval);
      const d1 = Math.floor(Math.random() * 6) + 1;
      const d2 = Math.floor(Math.random() * 6) + 1;
      const resultTotal = d1 + d2;
      const win = (selectedSide === 'over' && resultTotal > 7) || (selectedSide === 'under' && resultTotal < 7);

      setDice1(d1);
      setDice2(d2);
      setTotal(resultTotal);
      setIsWin(win);
      setDice1Rotation((d1 - 1) * 60);
      setDice2Rotation((d2 - 1) * 60);
      setStatus('result');

      if (win) {
        const winAmount = betAmount * 2;
        updateBalance(winAmount);

        // Record win on server
        try {
          fetch('/api/game-transactions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId,
              game: 'dice',
              betAmount: betAmount.toString(),
              winAmount: winAmount.toString(),
              multiplier: '2.00',
              status: 'win',
            }),
          });
        } catch (error) {
          console.error('Failed to record win:', error);
        }

        toast.success(language === 'ru' ? `✓ ВЫИГРЫШ! +₽${winAmount.toFixed(2)}` : `✓ WIN! +₽${winAmount.toFixed(2)}`);
      } else {
        toast.error(language === 'ru' ? `✗ ПРОИГРЫШ! -₽${betAmount.toFixed(2)}` : `✗ LOSS! -₽${betAmount.toFixed(2)}`);
      }
    }, 2000);
  };

  const handlePlayAgain = () => {
    setStatus('idle');
    setDice1(1);
    setDice2(1);
    setTotal(2);
    setIsWin(false);
    setDice1Rotation(0);
    setDice2Rotation(0);
  };

  const renderDiceFace = (number: number) => {
    const dots = {
      1: [[50, 50]],
      2: [[25, 25], [75, 75]],
      3: [[25, 25], [50, 50], [75, 75]],
      4: [[25, 25], [75, 25], [25, 75], [75, 75]],
      5: [[25, 25], [75, 25], [50, 50], [25, 75], [75, 75]],
      6: [[25, 25], [75, 25], [25, 50], [75, 50], [25, 75], [75, 75]],
    };

    return (
      <div className="relative w-24 h-24">
        {dots[number as keyof typeof dots]?.map((pos, i) => (
          <div
            key={i}
            className="absolute w-3 h-3 bg-red-500 rounded-full"
            style={{ left: `${pos[0]}%`, top: `${pos[1]}%`, transform: 'translate(-50%, -50%)' }}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
      {/* Game Display */}
      <div className="lg:col-span-2 relative min-h-[500px] glass-card rounded-2xl overflow-hidden flex flex-col p-6" style={{background: 'linear-gradient(135deg, #2a1810 0%, #3d2415 50%, #4a2c1a 100%)'}}>
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(249,115,22,0.1)_0%,_transparent_70%)]" />
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 4, repeat: Infinity }}
            className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(249,115,22,0.05)_0%,_transparent_70%)]"
          />
        </div>

        <div className="relative z-10 flex-1 flex items-center justify-center">
          {status === 'idle' ? (
            <div className="text-center">
              <motion.div animate={{ y: [0, -10, 0] }} transition={{ duration: 2, repeat: Infinity }}>
                <Dices className="w-20 h-20 mx-auto text-orange-400 mb-4 drop-shadow-[0_0_20px_rgba(249,115,22,0.6)]" />
              </motion.div>
              <h2 className="text-4xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-orange-300 to-yellow-300 mb-3 drop-shadow-[0_0_10px_rgba(249,115,22,0.4)]">КУБИКИ</h2>
              <p className="text-pink-300 mb-8 text-lg">
                {language === 'ru' ? 'Предскажите сумму костей' : 'Predict the dice total'}
              </p>
              <Button
                size="lg"
                className="bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white font-bold shadow-[0_0_30px_rgba(249,115,22,0.5)]"
                onClick={handleRoll}
              >
                {language === 'ru' ? 'Начать игру' : 'Start Game'}
              </Button>
            </div>
          ) : (
            <div className="flex gap-8 items-center justify-center">
              <motion.div
                animate={{ rotateX: dice1Rotation }}
                transition={{ duration: status === 'rolling' ? 2 : 0.5 }}
                className="w-24 h-24 bg-gradient-to-br from-white to-gray-200 rounded-lg flex items-center justify-center shadow-[0_0_30px_rgba(249,115,22,0.6)] border-2 border-orange-400/50"
                style={{ perspective: '1000px' }}
              >
                {renderDiceFace(dice1)}
              </motion.div>
              <div className="text-4xl font-black text-orange-400 font-orbitron">+</div>
              <motion.div
                animate={{ rotateX: dice2Rotation }}
                transition={{ duration: status === 'rolling' ? 2 : 0.5 }}
                className="w-24 h-24 bg-gradient-to-br from-white to-gray-200 rounded-lg flex items-center justify-center shadow-[0_0_30px_rgba(249,115,22,0.6)] border-2 border-orange-400/50"
                style={{ perspective: '1000px' }}
              >
                {renderDiceFace(dice2)}
              </motion.div>
            </div>
          )}
        </div>

        {status === 'result' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative z-10 text-center mt-8">
            <h3 className={`text-5xl font-black font-orbitron mb-2 drop-shadow-lg ${isWin ? 'text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500' : 'text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-pink-500'}`}>
              {isWin ? (language === 'ru' ? 'ПОБЕДА!' : 'WIN!') : (language === 'ru' ? 'ПРОИГРЫШ!' : 'LOSS!')}
            </h3>
            <p className="text-2xl text-orange-300 mb-2 font-bold">= {total}</p>
            <p className="text-lg text-orange-300 mb-6">
              {selectedSide === 'over' ? (language === 'ru' ? 'Больше 7' : 'Over 7') : (language === 'ru' ? 'Меньше 7' : 'Under 7')}
            </p>
            <Button size="lg" className="bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white font-bold" onClick={handlePlayAgain}>
              {language === 'ru' ? 'Ещё раз' : 'Play Again'}
            </Button>
          </motion.div>
        )}
      </div>

      {/* Settings Panel */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between min-h-[500px] bg-gradient-to-b from-orange-950/30 to-orange-950/30 border border-orange-500/30 shadow-[0_0_30px_rgba(249,115,22,0.2)]">
        <div>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-300">
                {language === 'ru' ? 'СТАВКА' : 'STAKE'}
              </h2>
              <p className="text-sm text-emerald-400 font-mono mt-2 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]">₽{userBalance.toFixed(2)}</p>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex justify-between text-sm">
              <span className="text-orange-300">{language === 'ru' ? 'Размер ставки' : 'Bet Amount'}</span>
              <span className="text-orange-100 font-bold">₽{betAmount}</span>
            </div>
            <Input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Number(e.target.value))}
              className="h-12 text-lg font-mono bg-black/40 border border-orange-500/50 focus:border-orange-400 text-center text-orange-200 placeholder-orange-500/50"
              disabled={status !== 'idle'}
              min="1"
            />

            <div className="space-y-3 mt-6">
              <p className="text-sm font-bold text-orange-300">{language === 'ru' ? 'Выберите вариант' : 'Pick a bet'}</p>
              <div className="grid grid-cols-2 gap-2">
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => setSelectedSide('over')}
                    disabled={status !== 'idle'}
                    className={`w-full h-12 font-bold transition-all ${
                      selectedSide === 'over'
                        ? 'bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 shadow-[0_0_20px_rgba(249,115,22,0.5)]'
                        : 'bg-orange-600/30 hover:bg-orange-600/50 border border-orange-500/30'
                    }`}
                  >
                    🔼 {language === 'ru' ? 'Больше 7' : 'Over 7'}
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={() => setSelectedSide('under')}
                    disabled={status !== 'idle'}
                    className={`w-full h-12 font-bold transition-all ${
                      selectedSide === 'under'
                        ? 'bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 shadow-[0_0_20px_rgba(249,115,22,0.5)]'
                        : 'bg-orange-600/30 hover:bg-orange-600/50 border border-orange-500/30'
                    }`}
                  >
                    🔽 {language === 'ru' ? 'Меньше 7' : 'Under 7'}
                  </Button>
                </motion.div>
              </div>
            </div>

            <div className="space-y-2 text-xs text-orange-300 mt-8 bg-orange-950/30 p-4 rounded-lg border border-orange-500/20">
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Шанс' : 'Chance'}</span>
                <span className="text-orange-100 font-bold">~48%</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Коэффициент' : 'Multiplier'}</span>
                <span className="text-orange-100 font-bold">2x</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ru' ? 'Возможный выигрыш' : 'Possible Win'}</span>
                <span className="text-emerald-400 font-bold">₽{(betAmount * 2).toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Button
            size="lg"
            className="w-full h-14 text-lg font-black font-orbitron uppercase bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 shadow-[0_0_30px_rgba(249,115,22,0.6)]"
            onClick={handleRoll}
            disabled={status !== 'idle'}
          >
            {status === 'idle' ? (language === 'ru' ? '🎲 КИДАТЬ!' : '🎲 ROLL!') : (language === 'ru' ? '⏳ КИДАЕМ...' : '⏳ ROLLING...')}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
